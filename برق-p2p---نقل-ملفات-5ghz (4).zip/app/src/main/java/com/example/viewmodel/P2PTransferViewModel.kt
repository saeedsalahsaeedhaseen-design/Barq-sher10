package com.example.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DeviceMediaRepository
import com.example.data.InstalledAppsRepository
import com.example.model.AppScreen
import com.example.model.ChunkSizeOption
import com.example.model.DeviceMediaItem
import com.example.model.DiscoveredPeerSession
import com.example.model.FileCategory
import com.example.model.FileTransferStatus
import com.example.model.FilesSubTab
import com.example.model.FolderBatchInfo
import com.example.model.HotspotNetworkStatus
import com.example.model.InstalledAppItem
import com.example.model.SortOption
import com.example.model.StorageFolderItem
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.model.TransferHistoryRecord
import com.example.network.P2PChunkServer
import com.example.util.Sha256Util
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max
import kotlin.random.Random

data class P2PUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val networkStatus: HotspotNetworkStatus = HotspotNetworkStatus(),
    val connectionCode: String = "BRQ-4301",
    val enteredReceiveCode: String = "",
    val isSenderReady: Boolean = false,
    val isPreparingHashes: Boolean = false,
    val remoteHostIp: String = "",
    val remoteHostPort: Int = 8989,
    val remoteSessionCode: String = "",
    val remoteChunkSizeBytes: Int = ChunkSizeOption.CHUNK_1MB.bytes,
    val pendingIncomingFiles: List<TransferFileItem> = emptyList(),
    val showReceiveConfirmationDialog: Boolean = false,
    val isConnectingToSender: Boolean = false,
    val discoveredPeers: List<DiscoveredPeerSession> = emptyList(),
    val selectedChunkSize: ChunkSizeOption = ChunkSizeOption.CHUNK_1MB,
    val transferDirection: TransferDirection = TransferDirection.SENDING,
    val files: List<TransferFileItem> = emptyList(),
    val folderBatches: List<FolderBatchInfo> = emptyList(),
    val isScanningFolder: Boolean = false,
    val isTransferRunning: Boolean = false,
    val isPaused: Boolean = false,
    val liveOverallSpeedBytesPerSec: Double = 0.0,
    val peakSpeedBytesPerSec: Double = 0.0,
    val statusBannerMessage: String? = null,
    val showHotspotGuideSheet: Boolean = false,
    val connectedPeerLabel: String = "بانتظار اتصال الجهاز الآخر...",
    // Installed Apps State
    val installedApps: List<InstalledAppItem> = emptyList(),
    val isLoadingApps: Boolean = false,
    val includeSystemApps: Boolean = false,
    val appsSearchQuery: String = "",
    val selectedAppPackages: Set<String> = emptySet(),
    // Device Media & File Manager State
    val hasMediaPermissions: Boolean = false,
    val permissionDeniedMessage: String? = null,
    val isLoadingMedia: Boolean = false,
    val deviceImages: List<DeviceMediaItem> = emptyList(),
    val deviceVideos: List<DeviceMediaItem> = emptyList(),
    val deviceAudio: List<DeviceMediaItem> = emptyList(),
    val deviceGeneralFiles: List<DeviceMediaItem> = emptyList(),
    val storageFolders: List<StorageFolderItem> = emptyList(),
    val safFolderFiles: List<DeviceMediaItem> = emptyList(),
    val activeFilesSubTab: FilesSubTab = FilesSubTab.ALL,
    val browsingFolderFilter: String? = null,
    val mediaSearchQuery: String = "",
    val sortOption: SortOption = SortOption.DATE_DESC,
    val selectedFolderPaths: Set<String> = emptySet(),
    val selectedMediaIds: Set<String> = emptySet(),
    // Transfer History State
    val transferHistory: List<TransferHistoryRecord> = emptyList()
) {
    val totalBytes: Long
        get() = files.sumOf { it.sizeBytes }

    val transferredBytes: Long
        get() = files.sumOf { it.transferredBytes }

    val overallProgressFraction: Float
        get() = when {
            files.isNotEmpty() && files.all { it.status == FileTransferStatus.COMPLETED } -> 1f
            totalBytes <= 0L -> if (totalChunksCount > 0) (completedChunksCount.toFloat() / totalChunksCount.toFloat()).coerceIn(0f, 1f) else 0f
            else -> (transferredBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
        }

    val totalChunksCount: Int
        get() = files.sumOf { it.totalChunks }

    val completedChunksCount: Int
        get() = files.sumOf { it.completedChunks }

    val totalFilesOnlyCount: Int
        get() = files.count { !it.isDirectory }

    val totalEmptyDirsCount: Int
        get() = files.count { it.isDirectory }

    val standaloneFilesInQueue: List<TransferFileItem>
        get() = files.filter { it.folderBatchId.isBlank() }

    val totalSelectedUnitsInSendQueue: Int
        get() = folderBatches.size + standaloneFilesInQueue.size

    val activeFolderNames: List<String>
        get() = files.mapNotNull { it.rootFolderName.takeIf { name -> name.isNotBlank() } }.distinct()

    val pendingTotalBytes: Long
        get() = pendingIncomingFiles.sumOf { it.sizeBytes }

    val pendingFolderNames: List<String>
        get() = pendingIncomingFiles.mapNotNull { it.rootFolderName.takeIf { name -> name.isNotBlank() } }.distinct()

    val liveOverallSpeedMbps: Double
        get() = liveOverallSpeedBytesPerSec / (1024.0 * 1024.0)

    val peakSpeedMbps: Double
        get() = peakSpeedBytesPerSec / (1024.0 * 1024.0)

    val qrPayload: String
        get() = "BARQP2P|$connectionCode|${networkStatus.localIp}|${networkStatus.port}"

    val selectedFoldersCount: Int
        get() = selectedFolderPaths.size

    val selectedFilesAndAppsCount: Int
        get() = selectedAppPackages.size + selectedMediaIds.size

    val totalSelectedCountInManager: Int
        get() = selectedFolderPaths.size + selectedAppPackages.size + selectedMediaIds.size

    val totalSelectedBytesInManager: Long
        get() {
            val foldersBytes = storageFolders
                .filter { it.path in selectedFolderPaths }
                .sumOf { it.totalBytes }
            val appsBytes = installedApps
                .filter { it.packageName in selectedAppPackages }
                .sumOf { it.sizeBytes }
            val allMedia = (deviceImages + deviceVideos + deviceAudio + deviceGeneralFiles + safFolderFiles)
                .distinctBy { it.id }
            val mediaBytes = allMedia
                .filter { it.id in selectedMediaIds }
                .sumOf { it.sizeBytes }
            return foldersBytes + appsBytes + mediaBytes
        }
}

class P2PTransferViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(P2PUiState())
    val uiState: StateFlow<P2PUiState> = _uiState.asStateFlow()

    private var chunkServer: P2PChunkServer? = null
    private var activeTransferJob: Job? = null
    private val senderFileStartNanoMap = ConcurrentHashMap<String, Long>()
    private val senderFileServedBytesMap = ConcurrentHashMap<String, Long>()
    private var senderSessionStartNano: Long = 0L
    private val senderSessionServedBytes = AtomicLong(0L)
    private var lastSenderUiUpdateNano: Long = 0L

    init {
        checkMediaPermissionsStatus()
        loadPersistedHistory()
        startLocalP2PServerAndInspectNetwork()
        loadInstalledApps()
        loadAllDeviceMediaAndFiles()
    }

    fun checkMediaPermissionsStatus(): Boolean {
        val ctx = getApplication<Application>().applicationContext
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
        _uiState.update { it.copy(hasMediaPermissions = granted) }
        return granted
    }

    fun onMediaPermissionsResult(results: Map<String, Boolean>) {
        val anyGranted = results.values.any { it } || checkMediaPermissionsStatus()
        _uiState.update {
            it.copy(
                hasMediaPermissions = anyGranted,
                permissionDeniedMessage = if (!anyGranted) {
                    "تم رفض صلاحية قراءة الوسائط. لا يزال بإمكانك اختيار أي ملف أو إرسال مجلد كامل عبر متصفح ملفات النظام الآمن (SAF)."
                } else null
            )
        }
        if (anyGranted) {
            loadAllDeviceMediaAndFiles()
        }
    }

    private fun startLocalP2PServerAndInspectNetwork() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val server = P2PChunkServer(
                context = appContext,
                scope = viewModelScope,
                sessionCodeProvider = { _uiState.value.connectionCode },
                isSenderReadyProvider = { _uiState.value.isSenderReady },
                chunkSizeProvider = { _uiState.value.selectedChunkSize },
                filesProvider = { _uiState.value.files },
                onChunkServed = { fileId, chunkIdx, bytesCount ->
                    onRemotePeerPulledChunk(fileId, chunkIdx, bytesCount)
                },
                onPeerDiscovered = { peerSession ->
                    _uiState.update { state ->
                        val updated = (listOf(peerSession) + state.discoveredPeers.filterNot {
                            it.sessionCode.equals(peerSession.sessionCode, ignoreCase = true)
                        }).take(8)
                        state.copy(discoveredPeers = updated)
                    }
                },
                onReceiverVerifiedFile = { fileId, verified ->
                    if (verified) {
                        updateFileState(fileId) { f ->
                            f.copy(
                                completedChunks = f.totalChunks,
                                transferredBytes = f.sizeBytes,
                                status = FileTransferStatus.COMPLETED,
                                sha256Verified = true
                            )
                        }
                    }
                }
            )
            val port = server.startServer()
            chunkServer = server
            val net = P2PChunkServer.inspectNetworkStatus(appContext, port, isServerRunning = true)
            val initialCode = buildShortCodeFromIp(net.localIp)
            _uiState.update {
                it.copy(
                    networkStatus = net,
                    connectionCode = initialCode,
                    enteredReceiveCode = ""
                )
            }
        }
    }

    private fun buildShortCodeFromIp(ip: String): String {
        val parts = ip.split(".")
        val lastOctet = parts.lastOrNull()?.toIntOrNull() ?: Random.nextInt(10, 99)
        val thirdOctet = parts.getOrNull(2)?.toIntOrNull() ?: 43
        val suffix = String.format(Locale.US, "%02d%02d", thirdOctet % 100, lastOctet % 100)
        return "BRQ-$suffix"
    }

    fun refreshNetworkStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val port = chunkServer?.boundPort ?: 8989
            val net = P2PChunkServer.inspectNetworkStatus(appContext, port, isServerRunning = true)
            val updatedCode = buildShortCodeFromIp(net.localIp)
            _uiState.update {
                it.copy(
                    networkStatus = net,
                    connectionCode = if (!it.isSenderReady) updatedCode else it.connectionCode,
                    statusBannerMessage = "تم تحديث الشبكة: ${net.localIp}:${net.port} (${net.networkTypeLabel})"
                )
            }
        }
    }

    fun regenerateConnectionCode() {
        val ip = _uiState.value.networkStatus.localIp
        val parts = ip.split(".")
        val lastOctet = parts.lastOrNull()?.toIntOrNull() ?: 1
        val thirdOctet = parts.getOrNull(2)?.toIntOrNull() ?: 43
        val newCode = String.format(Locale.US, "BRQ-%02d%02d", thirdOctet % 100, lastOctet % 100)
        _uiState.update {
            it.copy(
                connectionCode = newCode,
                statusBannerMessage = "تم تحديث كود الاتصال المباشر: $newCode (العنوان: $ip:${it.networkStatus.port})"
            )
        }
    }

    fun loadInstalledApps(includeSystem: Boolean = _uiState.value.includeSystemApps) {
        _uiState.update { it.copy(isLoadingApps = true, includeSystemApps = includeSystem) }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val apps = InstalledAppsRepository.loadInstalledSharableApps(ctx, includeSystem)
            _uiState.update {
                it.copy(
                    installedApps = apps,
                    isLoadingApps = false
                )
            }
        }
    }

    fun loadAllDeviceMediaAndFiles() {
        _uiState.update { it.copy(isLoadingMedia = true) }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val images = DeviceMediaRepository.loadImages(ctx)
            val videos = DeviceMediaRepository.loadVideos(ctx)
            val audio = DeviceMediaRepository.loadAudioFiles(ctx)
            val (generalFiles, folders) = DeviceMediaRepository.loadGeneralFilesAndFolders(ctx)
            _uiState.update {
                it.copy(
                    deviceImages = images,
                    deviceVideos = videos,
                    deviceAudio = audio,
                    deviceGeneralFiles = generalFiles,
                    storageFolders = folders,
                    isLoadingMedia = false
                )
            }
        }
    }

    /**
     * Dedicated "إرسال مجلد" (Send Entire Folder) feature via ACTION_OPEN_DOCUMENT_TREE.
     * Automatically persists URI access, recursively reads all files, subfolders, and empty folders,
     * adds the entire folder hierarchy to the Send Queue as one operation, and opens the Send screen.
     */
    fun onSendEntireFolderTreePicked(treeUri: Uri) {
        _uiState.update {
            it.copy(
                isScanningFolder = true,
                statusBannerMessage = "جاري فحص المجلد وبنيته الفرعية بالكامل لإرساله كوحدة واحدة..."
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val chunkBytes = _uiState.value.selectedChunkSize.bytes
            val scanResult = DeviceMediaRepository.scanDocumentTreeForTransfer(ctx, treeUri, chunkBytes)
            if (scanResult.errorMessage != null || scanResult.batchInfo == null) {
                _uiState.update {
                    it.copy(
                        isScanningFolder = false,
                        statusBannerMessage = scanResult.errorMessage ?: "تعذر قراءة المجلد المختار"
                    )
                }
                return@launch
            }
            val batch = scanResult.batchInfo
            _uiState.update { state ->
                val existingFiltered = state.files.filterNot { it.rootFolderName == batch.rootFolderName }
                val existingBatches = state.folderBatches.filterNot { it.rootFolderName == batch.rootFolderName }
                val skippedNote = if (batch.skippedUnreadableCount > 0) {
                    " (تم تخطي ${batch.skippedUnreadableCount} عنصر محمي من النظام)"
                } else ""
                state.copy(
                    isScanningFolder = false,
                    files = existingFiltered + scanResult.transferItems,
                    folderBatches = existingBatches + batch,
                    safFolderFiles = scanResult.previewMediaItems,
                    isSenderReady = false,
                    transferDirection = TransferDirection.SENDING,
                    currentScreen = AppScreen.SEND,
                    statusBannerMessage = "تم تجهيز المجلد «${batch.rootFolderName}» بالكامل (${batch.totalFilesCount} ملف و ${batch.totalSubfoldersCount} مجلد فرعي)$skippedNote. اضغط (بدء الإرسال) الآن!"
                )
            }
        }
    }

    /**
     * Sends a local accessible StorageFolderItem directory as a complete folder hierarchy
     * without requiring the user to pick individual files inside it.
     */
    fun sendLocalFolderDirectly(folderPath: String) {
        _uiState.update {
            it.copy(
                isScanningFolder = true,
                statusBannerMessage = "جاري قراءة المجلد المحلي وبنيته الفرعية لإرساله كاملاً..."
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            val chunkBytes = _uiState.value.selectedChunkSize.bytes
            val scanResult = DeviceMediaRepository.scanLocalFolderForTransfer(File(folderPath), chunkBytes)
            if (scanResult.errorMessage != null || scanResult.batchInfo == null) {
                _uiState.update {
                    it.copy(
                        isScanningFolder = false,
                        statusBannerMessage = scanResult.errorMessage ?: "تعذر قراءة المجلد المحلي"
                    )
                }
                return@launch
            }
            val batch = scanResult.batchInfo
            _uiState.update { state ->
                val existingFiltered = state.files.filterNot { it.rootFolderName == batch.rootFolderName }
                val existingBatches = state.folderBatches.filterNot { it.rootFolderName == batch.rootFolderName }
                state.copy(
                    isScanningFolder = false,
                    files = existingFiltered + scanResult.transferItems,
                    folderBatches = existingBatches + batch,
                    isSenderReady = false,
                    transferDirection = TransferDirection.SENDING,
                    currentScreen = AppScreen.SEND,
                    statusBannerMessage = "تم تجهيز المجلد «${batch.rootFolderName}» بالكامل (${batch.totalFilesCount} ملف و ${batch.totalSubfoldersCount} مجلد فرعي). اضغط (بدء الإرسال) الآن!"
                )
            }
        }
    }

    fun removeFolderBatch(batchId: String) {
        _uiState.update { state ->
            val remainingFiles = state.files.filterNot { it.folderBatchId == batchId }
            val remainingBatches = state.folderBatches.filterNot { it.batchId == batchId }
            state.copy(
                files = remainingFiles,
                folderBatches = remainingBatches,
                isSenderReady = if (remainingFiles.isEmpty()) false else state.isSenderReady
            )
        }
    }

    /**
     * Kept for backward compatibility: picking a folder from SAF immediately prepares the entire folder for sending.
     */
    fun onSafFolderPicked(treeUri: Uri) {
        onSendEntireFolderTreePicked(treeUri)
    }

    fun updateAppsSearchQuery(query: String) {
        _uiState.update { it.copy(appsSearchQuery = query) }
    }

    fun updateMediaSearchQuery(query: String) {
        _uiState.update { it.copy(mediaSearchQuery = query) }
    }

    fun setSortOption(option: SortOption) {
        _uiState.update { it.copy(sortOption = option) }
    }

    fun setActiveFilesSubTab(subTab: FilesSubTab) {
        _uiState.update { it.copy(activeFilesSubTab = subTab, browsingFolderFilter = null) }
    }

    fun setBrowsingFolderFilter(folderRelativePath: String?) {
        _uiState.update { it.copy(browsingFolderFilter = folderRelativePath) }
    }

    fun toggleFolderSelection(folderPath: String) {
        _uiState.update { state ->
            val next = state.selectedFolderPaths.toMutableSet()
            if (!next.add(folderPath)) next.remove(folderPath)
            state.copy(selectedFolderPaths = next)
        }
    }

    fun selectAllVisibleFoldersAndMedia(visibleFolderPaths: List<String>, visibleMediaIds: List<String>) {
        _uiState.update { state ->
            val allFoldersSelected = visibleFolderPaths.isNotEmpty() && visibleFolderPaths.all { it in state.selectedFolderPaths }
            val allMediaSelected = visibleMediaIds.isNotEmpty() && visibleMediaIds.all { it in state.selectedMediaIds }
            val shouldDeselect = (visibleFolderPaths.isEmpty() || allFoldersSelected) &&
                (visibleMediaIds.isEmpty() || allMediaSelected) &&
                (visibleFolderPaths.isNotEmpty() || visibleMediaIds.isNotEmpty())

            if (shouldDeselect) {
                state.copy(
                    selectedFolderPaths = state.selectedFolderPaths - visibleFolderPaths.toSet(),
                    selectedMediaIds = state.selectedMediaIds - visibleMediaIds.toSet()
                )
            } else {
                state.copy(
                    selectedFolderPaths = state.selectedFolderPaths + visibleFolderPaths,
                    selectedMediaIds = state.selectedMediaIds + visibleMediaIds
                )
            }
        }
    }

    /**
     * Locates a folder by relative path (e.g. "Download/ropon" or "ropon") or absolute path,
     * registers it in storageFolders if not already listed, and selects it as a single folder transfer unit.
     */
    fun addOrSelectFolderByPath(rawInput: String) {
        val cleaned = rawInput.trim().trim('/').replace('\\', '/')
        if (cleaned.isBlank()) return
        val lower = cleaned.lowercase(Locale.ROOT)
        if (lower.contains("android/data") || lower.contains("android/obb")) {
            _uiState.update {
                it.copy(statusBannerMessage = "تعذر تحديد هذا المجلد لأنه ضمن مجلدات النظام المحمية (Android/data أو Android/obb)")
            }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            val existingMatch = _uiState.value.storageFolders.firstOrNull {
                it.relativeDisplayPath.equals(cleaned, ignoreCase = true) ||
                    it.path.equals(rawInput.trim(), ignoreCase = true) ||
                    it.name.equals(cleaned, ignoreCase = true)
            }
            if (existingMatch != null) {
                _uiState.update { state ->
                    state.copy(
                        selectedFolderPaths = state.selectedFolderPaths + existingMatch.path,
                        statusBannerMessage = "تم تحديد المجلد «${existingMatch.relativeDisplayPath}» كعنصر نقل واحد"
                    )
                }
                return@launch
            }

            @Suppress("DEPRECATION")
            val extRoot = Environment.getExternalStorageDirectory()
            @Suppress("DEPRECATION")
            val pubDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val candidates = listOfNotNull(
                File(rawInput.trim()).takeIf { it.isAbsolute },
                extRoot?.let { File(it, cleaned) },
                pubDownloads?.let { File(it, cleaned.removePrefix("Download/").removePrefix("download/")) }
            )
            val foundDir = candidates.firstOrNull { it.exists() && it.isDirectory && it.canRead() }
            if (foundDir == null) {
                _uiState.update {
                    it.copy(statusBannerMessage = "تعذر العثور على المجلد ($cleaned) في التخزين المتاح")
                }
                return@launch
            }

            val chunkBytes = _uiState.value.selectedChunkSize.bytes
            val scan = DeviceMediaRepository.scanLocalFolderForTransfer(foundDir, chunkBytes)
            val batch = scan.batchInfo
            val relDisplay = if (cleaned.contains('/')) cleaned else "Download/${foundDir.name}"
            val newFolderItem = StorageFolderItem(
                name = foundDir.name,
                path = foundDir.absolutePath,
                relativeDisplayPath = relDisplay,
                parentFolderName = relDisplay.substringBeforeLast('/', ""),
                fileCount = batch?.totalFilesCount ?: 0,
                subfolderCount = batch?.totalSubfoldersCount ?: 0,
                emptySubfolderCount = batch?.emptyFoldersCount ?: 0,
                totalBytes = batch?.totalBytes ?: 0L,
                lastModifiedMillis = foundDir.lastModified()
            )
            _uiState.update { state ->
                val updatedFolders = (listOf(newFolderItem) + state.storageFolders.filterNot { it.path == newFolderItem.path })
                state.copy(
                    storageFolders = updatedFolders,
                    selectedFolderPaths = state.selectedFolderPaths + newFolderItem.path,
                    statusBannerMessage = "تم العثور على المجلد «${newFolderItem.relativeDisplayPath}» وتحديده للإرسال الكامل"
                )
            }
        }
    }

    fun toggleAppSelection(packageName: String) {
        _uiState.update { state ->
            val next = state.selectedAppPackages.toMutableSet()
            if (!next.add(packageName)) next.remove(packageName)
            state.copy(selectedAppPackages = next)
        }
    }

    fun selectAllVisibleApps(visiblePackages: List<String>) {
        _uiState.update { state ->
            state.copy(selectedAppPackages = state.selectedAppPackages + visiblePackages)
        }
    }

    fun toggleMediaSelection(mediaId: String) {
        _uiState.update { state ->
            val next = state.selectedMediaIds.toMutableSet()
            if (!next.add(mediaId)) next.remove(mediaId)
            state.copy(selectedMediaIds = next)
        }
    }

    fun selectAllVisibleMedia(visibleIds: List<String>) {
        _uiState.update { state ->
            state.copy(selectedMediaIds = state.selectedMediaIds + visibleIds)
        }
    }

    fun clearAllManagerSelections() {
        _uiState.update {
            it.copy(
                selectedFolderPaths = emptySet(),
                selectedAppPackages = emptySet(),
                selectedMediaIds = emptySet()
            )
        }
    }

    /**
     * Converts all selected Storage Folders (each treated as a unified FolderBatchInfo containing
     * all its nested files, subfolders, and empty directories), Installed Apps, and standalone files
     * into the Send Queue in one combined operation and navigates to the Send screen.
     */
    fun addManagerSelectionsToSendQueueAndGoToSend() {
        val state = _uiState.value
        val chunkBytes = state.selectedChunkSize.bytes
        val selectedFolderPathsSnap = state.selectedFolderPaths
        val selectedAppPkgsSnap = state.selectedAppPackages
        val selectedMediaIdsSnap = state.selectedMediaIds

        if (selectedFolderPathsSnap.isEmpty() && selectedAppPkgsSnap.isEmpty() && selectedMediaIdsSnap.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "الرجاء تحديد مجلد أو ملف أو تطبيق واحد على الأقل أولاً")
            }
            return
        }

        _uiState.update {
            it.copy(
                isScanningFolder = selectedFolderPathsSnap.isNotEmpty(),
                statusBannerMessage = if (selectedFolderPathsSnap.isNotEmpty()) {
                    "جاري تجهيز المجلدات والملفات المحددة ببنيتها الكاملة للإرسال..."
                } else null
            )
        }

        viewModelScope.launch(Dispatchers.IO) {
            val currentState = _uiState.value
            val newTransferItems = mutableListOf<TransferFileItem>()
            val newFolderBatches = mutableListOf<FolderBatchInfo>()
            val replacedRootFolderNames = HashSet<String>()

            // 1. Scan all selected folders recursively as unified transfer batches
            for (folderPath in selectedFolderPathsSnap) {
                val folderItem = currentState.storageFolders.find { it.path == folderPath }
                    ?: StorageFolderItem(
                        name = File(folderPath).name.ifBlank { "Folder" },
                        path = folderPath,
                        relativeDisplayPath = File(folderPath).name,
                        fileCount = 0,
                        totalBytes = 0L,
                        lastModifiedMillis = System.currentTimeMillis()
                    )
                val scanResult = DeviceMediaRepository.scanStorageFolderItemForTransfer(folderItem, chunkBytes)
                if (scanResult.batchInfo != null && scanResult.errorMessage == null) {
                    newFolderBatches.add(scanResult.batchInfo)
                    replacedRootFolderNames.add(scanResult.batchInfo.rootFolderName)
                    newTransferItems.addAll(scanResult.transferItems)
                }
            }

            // 2. Add all selected Installed Apps
            val selectedApps = currentState.installedApps.filter { it.packageName in selectedAppPkgsSnap }
            for (app in selectedApps) {
                val safeFileName = "${app.appName.replace(Regex("[\\\\/:*?\"<>|]"), "_")}_v${app.versionName}.apk"
                val totalChunks = max(1, ((app.sizeBytes + chunkBytes - 1) / chunkBytes).toInt())
                newTransferItems.add(
                    TransferFileItem(
                        id = "apk_${app.packageName.hashCode()}_${System.currentTimeMillis() % 1000}",
                        name = safeFileName,
                        sizeBytes = app.sizeBytes,
                        category = FileCategory.GAME_APK,
                        localFile = app.apkFile,
                        packageName = app.packageName,
                        hasSplitWarning = app.hasSplitApks,
                        totalChunks = totalChunks
                    )
                )
            }

            // 3. Add all selected standalone Media / Files
            val allMedia = (currentState.deviceImages + currentState.deviceVideos + currentState.deviceAudio +
                currentState.deviceGeneralFiles + currentState.safFolderFiles).distinctBy { it.id }
            val selectedMedia = allMedia.filter { it.id in selectedMediaIdsSnap }
            for (media in selectedMedia) {
                val totalChunks = max(1, ((media.sizeBytes + chunkBytes - 1) / chunkBytes).toInt())
                newTransferItems.add(
                    TransferFileItem(
                        id = "m_${media.id}_${System.currentTimeMillis() % 1000}",
                        name = media.name.substringAfterLast('/'),
                        sizeBytes = media.sizeBytes,
                        category = media.category,
                        uri = media.uri,
                        localFile = media.localFile,
                        totalChunks = totalChunks,
                        sha256Expected = if (media.sizeBytes == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
                    )
                )
            }

            if (newTransferItems.isEmpty()) {
                _uiState.update {
                    it.copy(
                        isScanningFolder = false,
                        statusBannerMessage = "تعذر قراءة العناصر المحددة، يرجى التأكد من صلاحية الوصول"
                    )
                }
                return@launch
            }

            _uiState.update { current ->
                val retainedExistingFiles = current.files.filterNot {
                    it.rootFolderName.isNotBlank() && it.rootFolderName in replacedRootFolderNames
                }
                val retainedExistingBatches = current.folderBatches.filterNot {
                    it.rootFolderName in replacedRootFolderNames
                }
                val combinedFiles = (retainedExistingFiles + newTransferItems)
                    .distinctBy { "${it.displayPathOrName}:${it.sizeBytes}:${it.isDirectory}" }
                val combinedBatches = (retainedExistingBatches + newFolderBatches)
                    .distinctBy { it.rootFolderName }

                val summaryParts = mutableListOf<String>()
                if (newFolderBatches.isNotEmpty()) {
                    val foldersNames = newFolderBatches.joinToString("، ") { "«${it.rootFolderName}»" }
                    summaryParts.add("${newFolderBatches.size} مجلد كامل ($foldersNames)")
                }
                val standaloneAddedCount = selectedApps.size + selectedMedia.size
                if (standaloneAddedCount > 0) {
                    summaryParts.add("$standaloneAddedCount ملف/تطبيق")
                }

                current.copy(
                    isScanningFolder = false,
                    files = combinedFiles,
                    folderBatches = combinedBatches,
                    selectedFolderPaths = emptySet(),
                    selectedAppPackages = emptySet(),
                    selectedMediaIds = emptySet(),
                    isSenderReady = false,
                    transferDirection = TransferDirection.SENDING,
                    currentScreen = AppScreen.SEND,
                    statusBannerMessage = "تم تجهيز ${summaryParts.joinToString(" و ")} في قائمة الإرسال. اضغط (بدء الإرسال) الآن!"
                )
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        if (screen == AppScreen.LIVE_TRANSFER && _uiState.value.files.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال")
            }
            return
        }
        _uiState.update { it.copy(currentScreen = screen, statusBannerMessage = null) }
    }

    fun toggleHotspotGuideSheet(show: Boolean) {
        _uiState.update { it.copy(showHotspotGuideSheet = show) }
    }

    fun setChunkSize(option: ChunkSizeOption) {
        _uiState.update { state ->
            val updatedFiles = state.files.map { file ->
                val newTotalChunks = max(1, ((file.sizeBytes + option.bytes - 1) / option.bytes).toInt())
                file.copy(
                    totalChunks = newTotalChunks,
                    completedChunks = if (file.status == FileTransferStatus.COMPLETED) newTotalChunks else 0,
                    transferredBytes = if (file.status == FileTransferStatus.COMPLETED) file.sizeBytes else 0L
                )
            }
            state.copy(
                selectedChunkSize = option,
                files = updatedFiles,
                statusBannerMessage = "تم ضبط حجم الدفعة (Chunk Size) إلى ${option.label}"
            )
        }
    }

    fun updateEnteredReceiveCode(code: String) {
        _uiState.update { it.copy(enteredReceiveCode = code) }
    }

    fun clearBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun addPickedUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val appContext = getApplication<Application>().applicationContext
        val resolver = appContext.contentResolver
        val chunkBytes = _uiState.value.selectedChunkSize.bytes

        val addedItems = uris.mapNotNull { uri ->
            var displayName = "ملف_مرسل_${System.currentTimeMillis() % 10000}"
            var sizeBytes = 0L
            try {
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx >= 0) {
                            displayName = cursor.getString(nameIdx) ?: displayName
                        }
                        if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                            sizeBytes = cursor.getLong(sizeIdx)
                        }
                    }
                }
            } catch (_: Exception) {
            }
            if (sizeBytes <= 0L) {
                try {
                    resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                        if (afd.length > 0) sizeBytes = afd.length
                    }
                } catch (_: Exception) {
                }
            }
            if (sizeBytes < 0L) return@mapNotNull null

            val mime = resolver.getType(uri)
            val category = FileCategory.fromFileName(displayName, mime)
            val totalChunks = max(1, ((sizeBytes + chunkBytes - 1) / chunkBytes).toInt())

            TransferFileItem(
                id = UUID.randomUUID().toString().take(8),
                name = displayName,
                sizeBytes = sizeBytes,
                category = category,
                uri = uri,
                totalChunks = totalChunks,
                sha256Expected = if (sizeBytes == 0L) Sha256Util.EMPTY_BYTES_SHA256 else ""
            )
        }

        if (addedItems.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "تعذر قراءة الملف المحدد، يرجى اختيار ملف صالح من الجهاز")
            }
            return
        }

        _uiState.update { state ->
            state.copy(
                files = (state.files + addedItems).distinctBy { "${it.displayPathOrName}:${it.sizeBytes}" },
                isSenderReady = false,
                transferDirection = TransferDirection.SENDING,
                statusBannerMessage = "تمت إضافة ${addedItems.size} ملفات. اضغط (بدء الإرسال) لتفعيل الربط للجوال المستلم."
            )
        }
    }

    fun removeFileItem(fileId: String) {
        _uiState.update { state ->
            val remaining = state.files.filterNot { it.id == fileId }
            val activeBatchIds = remaining.mapNotNull { it.folderBatchId.takeIf { b -> b.isNotBlank() } }.toSet()
            val remainingBatches = state.folderBatches.filter { it.batchId in activeBatchIds }
            state.copy(
                files = remaining,
                folderBatches = remainingBatches,
                isSenderReady = if (remaining.isEmpty()) false else state.isSenderReady
            )
        }
    }

    fun clearAllFiles() {
        activeTransferJob?.cancel()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        senderSessionServedBytes.set(0L)
        _uiState.update {
            it.copy(
                files = emptyList(),
                folderBatches = emptyList(),
                isSenderReady = false,
                isTransferRunning = false,
                isPaused = false,
                liveOverallSpeedBytesPerSec = 0.0
            )
        }
    }

    /**
     * Cancels the active transfer session, cleans up temporary .part files, and updates state.
     */
    fun cancelActiveTransfer() {
        activeTransferJob?.cancel()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        senderSessionServedBytes.set(0L)
        _uiState.update { state ->
            val updatedFiles = state.files.map { f ->
                if (f.status == FileTransferStatus.TRANSFERRING || f.status == FileTransferStatus.QUEUED || f.status == FileTransferStatus.PAUSED) {
                    f.copy(status = FileTransferStatus.CANCELLED, currentSpeedBytesPerSec = 0.0)
                } else f
            }
            state.copy(
                isSenderReady = false,
                isTransferRunning = false,
                isPaused = false,
                liveOverallSpeedBytesPerSec = 0.0,
                files = updatedFiles,
                connectedPeerLabel = "تم إلغاء جلسة النقل وتنظيف الموارد",
                statusBannerMessage = "تم إلغاء عملية النقل بنجاح"
            )
        }
    }

    private fun onRemotePeerPulledChunk(fileId: String, chunkIdx: Int, bytesCount: Int) {
        val nowNano = System.nanoTime()
        if (senderSessionStartNano == 0L) {
            senderSessionStartNano = nowNano
        }
        val startNano = senderFileStartNanoMap.getOrPut(fileId) { nowNano }
        val totalServedForFile = (senderFileServedBytesMap[fileId] ?: 0L) + bytesCount.toLong()
        senderFileServedBytesMap[fileId] = totalServedForFile
        val sessionTotalBytes = senderSessionServedBytes.addAndGet(bytesCount.toLong())

        val fileElapsedSec = max(0.002, (nowNano - startNano) / 1_000_000_000.0)
        val fileSpeedBytesPerSec = totalServedForFile.toDouble() / fileElapsedSec
        val sessionElapsedSec = max(0.002, (nowNano - senderSessionStartNano) / 1_000_000_000.0)
        val overallSpeedBytesPerSec = max(fileSpeedBytesPerSec, sessionTotalBytes.toDouble() / sessionElapsedSec)

        val currentItem = _uiState.value.files.find { it.id == fileId } ?: return
        val newCompleted = max(currentItem.completedChunks, chunkIdx + 1).coerceAtMost(currentItem.totalChunks)
        val newBytes = minOf(currentItem.sizeBytes, totalServedForFile)
        val isDone = currentItem.isDirectory || currentItem.sizeBytes == 0L ||
            newCompleted >= currentItem.totalChunks || newBytes >= currentItem.sizeBytes

        // Throttle intermediate UI StateFlow updates to ~45ms to eliminate CPU/recomposition overhead during high-speed streaming
        if (!isDone && (nowNano - lastSenderUiUpdateNano) < 45_000_000L) {
            return
        }
        lastSenderUiUpdateNano = nowNano

        var newlyCompletedItem: TransferFileItem? = null

        _uiState.update { state ->
            val updated = state.files.map { item ->
                if (item.id != fileId) item
                else {
                    val updatedItem = item.copy(
                        completedChunks = if (isDone) item.totalChunks else newCompleted,
                        transferredBytes = if (isDone) item.sizeBytes else newBytes,
                        status = if (isDone) FileTransferStatus.COMPLETED else FileTransferStatus.TRANSFERRING,
                        currentSpeedBytesPerSec = if (isDone) 0.0 else fileSpeedBytesPerSec,
                        sha256Verified = if (isDone) true else item.sha256Verified
                    )
                    if (isDone && item.status != FileTransferStatus.COMPLETED) {
                        newlyCompletedItem = updatedItem
                    }
                    updatedItem
                }
            }
            val allCompleted = updated.isNotEmpty() && updated.all { it.status == FileTransferStatus.COMPLETED }
            state.copy(
                files = updated,
                isTransferRunning = !allCompleted,
                connectedPeerLabel = if (allCompleted) {
                    "اكتمل إرسال جميع الملفات والمجلدات للمستلم بنجاح"
                } else {
                    "متصل بالجهاز المستلم • جاري التدفق المباشر عالي السرعة (Keep-Alive)"
                },
                liveOverallSpeedBytesPerSec = if (allCompleted) 0.0 else overallSpeedBytesPerSec,
                peakSpeedBytesPerSec = max(state.peakSpeedBytesPerSec, overallSpeedBytesPerSec),
                statusBannerMessage = if (allCompleted) {
                    "اكتمل إرسال جميع الملفات والمجلدات إلى الجهاز المستلم بنجاح!"
                } else {
                    state.statusBannerMessage
                }
            )
        }

        newlyCompletedItem?.let { completed ->
            if (!completed.isDirectory) {
                recordHistoryItem(
                    item = completed,
                    direction = TransferDirection.SENDING,
                    peerAddress = "Receiver",
                    avgSpeedBytesPerSec = overallSpeedBytesPerSec
                )
            }
        }
    }

    fun startLiveChunkedTransfer(direction: TransferDirection) {
        if (_uiState.value.files.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال"
                )
            }
            return
        }

        activeTransferJob?.cancel()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        senderSessionStartNano = 0L
        senderSessionServedBytes.set(0L)

        if (direction == TransferDirection.SENDING) {
            val chunkBytes = _uiState.value.selectedChunkSize.bytes
            _uiState.update { state ->
                val resetFiles = state.files.map { f ->
                    val totalChunks = max(1, ((f.sizeBytes + chunkBytes - 1) / chunkBytes).toInt())
                    f.copy(
                        totalChunks = totalChunks,
                        completedChunks = 0,
                        transferredBytes = 0L,
                        currentSpeedBytesPerSec = 0.0,
                        status = FileTransferStatus.QUEUED
                    )
                }
                state.copy(
                    currentScreen = AppScreen.LIVE_TRANSFER,
                    transferDirection = TransferDirection.SENDING,
                    isSenderReady = true,
                    isPreparingHashes = true,
                    files = resetFiles,
                    isTransferRunning = true,
                    isPaused = false,
                    liveOverallSpeedBytesPerSec = 0.0,
                    connectedPeerLabel = "جاري تجهيز البصمات الرقمية SHA-256 وتفعيل جلسة الإرسال (${state.connectionCode})...",
                    statusBannerMessage = "تم تفعيل وضع الإرسال! أدخل الكود (${state.connectionCode}) أو امسح رمز QR من الجهاز الثاني."
                )
            }

            // Compute streaming SHA-256 hashes in background and broadcast UDP presence immediately
            viewModelScope.launch(Dispatchers.IO) {
                chunkServer?.broadcastSenderPresence()
                val resolver = getApplication<Application>().contentResolver
                val currentFiles = _uiState.value.files
                for (item in currentFiles) {
                    if (!isActive) break
                    if (item.sha256Expected.isBlank()) {
                        val sha = Sha256Util.computeSha256(resolver, item)
                        updateFileState(item.id) { it.copy(sha256Expected = sha) }
                    }
                }
                chunkServer?.broadcastSenderPresence()
                withContext(Dispatchers.Main) {
                    _uiState.update { state ->
                        state.copy(
                            isPreparingHashes = false,
                            connectedPeerLabel = "بانتظار اتصال الجهاز المستلم بالكود (${state.connectionCode}) أو العنوان (${state.networkStatus.localIp}:${state.networkStatus.port})..."
                        )
                    }
                }
            }
            return
        }

        // RECEIVING direction
        _uiState.update { state ->
            val resetFiles = state.files.map { f ->
                if (f.completedChunks in 1 until f.totalChunks) {
                    f.copy(status = FileTransferStatus.QUEUED, currentSpeedBytesPerSec = 0.0)
                } else if (f.status == FileTransferStatus.COMPLETED) {
                    f
                } else {
                    f.copy(
                        completedChunks = 0,
                        transferredBytes = 0L,
                        currentSpeedBytesPerSec = 0.0,
                        status = FileTransferStatus.QUEUED
                    )
                }
            }
            state.copy(
                currentScreen = AppScreen.LIVE_TRANSFER,
                transferDirection = TransferDirection.RECEIVING,
                files = resetFiles,
                isTransferRunning = true,
                isPaused = false,
                liveOverallSpeedBytesPerSec = 0.0,
                connectedPeerLabel = "متصل بالمرسل (${state.remoteHostIp}:${state.remoteHostPort} • ${state.remoteSessionCode})"
            )
        }

        activeTransferJob = viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val hostIp = _uiState.value.remoteHostIp
            val hostPort = _uiState.value.remoteHostPort
            val sessionCode = _uiState.value.remoteSessionCode
            val chunkSizeBytes = _uiState.value.remoteChunkSizeBytes
            val downloadDir = resolveBarqSherDownloadsDir(appContext)

            val anyFailed = executeHighSpeedReceiveSession(
                hostIp = hostIp,
                hostPort = hostPort,
                sessionCode = sessionCode,
                chunkSizeBytes = chunkSizeBytes,
                downloadDir = downloadDir,
                itemsProvider = { _uiState.value.files },
                isPausedProvider = { _uiState.value.isPaused },
                onFileUpdated = { fileId, currentSpeed, sessionSpeed, transform ->
                    _uiState.update { state ->
                        val updatedFiles = state.files.map { f ->
                            if (f.id == fileId) transform(f) else f
                        }
                        state.copy(
                            files = updatedFiles,
                            liveOverallSpeedBytesPerSec = max(currentSpeed, sessionSpeed),
                            peakSpeedBytesPerSec = max(state.peakSpeedBytesPerSec, max(currentSpeed, sessionSpeed))
                        )
                    }
                },
                onFileCompleted = { completedItem, avgSpeed ->
                    if (!completedItem.isDirectory) {
                        recordHistoryItem(
                            item = completedItem,
                            direction = TransferDirection.RECEIVING,
                            peerAddress = "$hostIp:$hostPort",
                            avgSpeedBytesPerSec = avgSpeed
                        )
                    }
                },
                onFileFailed = { failedItem, errMsg ->
                    recordHistoryItem(
                        item = failedItem,
                        direction = TransferDirection.RECEIVING,
                        peerAddress = "$hostIp:$hostPort",
                        avgSpeedBytesPerSec = 0.0,
                        errorMessage = errMsg
                    )
                }
            )

            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        isTransferRunning = false,
                        liveOverallSpeedBytesPerSec = 0.0,
                        statusBannerMessage = if (anyFailed) {
                            "تعذر إكمال بعض الملفات بسبب انقطاع الاتصال. يمكنك الضغط على استئناف لإكمال الدفعات المتبقية."
                        } else {
                            "اكتمل استلام جميع الملفات والمجلدات ببنيتها الكاملة والتحقق من سلامتها (SHA-256) في (Downloads/BarqSher)!"
                        }
                    )
                }
                loadAllDeviceMediaAndFiles()
            }
        }
    }

    private fun resolveBarqSherDownloadsDir(appContext: Context): File {
        return try {
            @Suppress("DEPRECATION")
            val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val barqDir = File(publicDownloads, "BarqSher")
            if (barqDir.exists() || barqDir.mkdirs()) {
                barqDir
            } else {
                File(
                    appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir,
                    "BarqSher"
                ).apply { mkdirs() }
            }
        } catch (_: Exception) {
            File(
                appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir,
                "BarqSher"
            ).apply { mkdirs() }
        }
    }

    /**
     * Connects to a discovered peer session directly.
     */
    fun connectToDiscoveredPeer(peer: DiscoveredPeerSession) {
        connectAndReceiveFromInput("BARQP2P|${peer.sessionCode}|${peer.hostIp}|${peer.port}")
    }

    /**
     * Resolves the sender's IP, port, and session code from:
     * 1. QR payload: BARQP2P|code|ip|port
     * 2. Explicit IP & code: ip:port#code or ip#code
     * 3. Auto-discovered UDP peer matching the entered code
     * 4. Active UDP broadcast query (BARQ_FIND|code) + subnet scan across all local interfaces
     */
    fun connectAndReceiveFromInput(rawInput: String) {
        val cleaned = rawInput.trim()
        if (cleaned.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                )
            }
            return
        }

        _uiState.update { it.copy(isConnectingToSender = true, statusBannerMessage = null) }

        viewModelScope.launch(Dispatchers.IO) {
            val candidateEndpoints = mutableListOf<Pair<String, Int>>()
            val defaultPort = _uiState.value.networkStatus.port
            var sessionCode = ""

            if (cleaned.startsWith("BARQP2P|", ignoreCase = true)) {
                val tokens = cleaned.split("|")
                if (tokens.size >= 4) {
                    sessionCode = tokens[1].trim().uppercase(Locale.US)
                    val ip = tokens[2].trim()
                    val port = tokens[3].trim().toIntOrNull() ?: defaultPort
                    if (ip.isNotEmpty()) candidateEndpoints.add(ip to port)
                }
            } else if (cleaned.contains("#")) {
                val hostPart = cleaned.substringBefore("#").trim()
                val codePart = cleaned.substringAfter("#").trim().uppercase(Locale.US)
                sessionCode = if (codePart.startsWith("BRQ-") || codePart.startsWith("5G-")) codePart else "BRQ-$codePart"
                val ip = hostPart.substringBefore(":")
                val port = hostPart.substringAfter(":", "").toIntOrNull() ?: defaultPort
                if (ip.isNotEmpty()) candidateEndpoints.add(ip to port)
            } else {
                val normalizedCore = P2PChunkServer.normalizeCode(cleaned)
                if (normalizedCore.length == 4 && normalizedCore.all { it.isDigit() }) {
                    sessionCode = "BRQ-$normalizedCore"

                    _uiState.value.discoveredPeers.find {
                        P2PChunkServer.normalizeCode(it.sessionCode) == normalizedCore
                    }?.let { discovered ->
                        candidateEndpoints.add(discovered.hostIp to discovered.port)
                    }

                    sendUdpFindQuery(sessionCode)
                    delay(350L)
                    _uiState.value.discoveredPeers.find {
                        P2PChunkServer.normalizeCode(it.sessionCode) == normalizedCore
                    }?.let { discovered ->
                        candidateEndpoints.add(discovered.hostIp to discovered.port)
                    }

                    val thirdOctet = normalizedCore.substring(0, 2).toIntOrNull()
                    val fourthOctet = normalizedCore.substring(2, 4).toIntOrNull()
                    if (thirdOctet != null && fourthOctet != null) {
                        val allIps = _uiState.value.networkStatus.allLocalIps
                        for (localIp in allIps) {
                            val parts = localIp.split(".")
                            if (parts.size == 4) {
                                candidateEndpoints.add("${parts[0]}.${parts[1]}.$thirdOctet.$fourthOctet" to defaultPort)
                                candidateEndpoints.add("${parts[0]}.${parts[1]}.${parts[2]}.$fourthOctet" to defaultPort)
                            }
                        }
                        candidateEndpoints.add("192.168.$thirdOctet.$fourthOctet" to 8989)
                    }
                }
            }

            val distinctEndpoints = candidateEndpoints.distinct()
            if (distinctEndpoints.isEmpty() || sessionCode.isBlank()) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            isConnectingToSender = false,
                            showReceiveConfirmationDialog = false,
                            pendingIncomingFiles = emptyList(),
                            statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                        )
                    }
                }
                return@launch
            }

            var fetchedRemoteFiles: List<TransferFileItem>? = null
            var remoteChunkSize = _uiState.value.selectedChunkSize.bytes
            var resolvedIp = ""
            var resolvedPort = defaultPort

            for ((targetIp, targetPort) in distinctEndpoints) {
                try {
                    val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                    val url = URL("http://$targetIp:$targetPort/api/manifest?code=$encodedCode")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 2500
                        readTimeout = 4000
                        requestMethod = "GET"
                    }
                    if (conn.responseCode == 200) {
                        val body = BufferedInputStream(conn.inputStream).bufferedReader().readText()
                        val json = JSONObject(body)
                        remoteChunkSize = json.optInt("chunkSize", remoteChunkSize)
                        val arr = json.optJSONArray("files")
                        if (arr != null && arr.length() > 0) {
                            val list = mutableListOf<TransferFileItem>()
                            for (i in 0 until arr.length()) {
                                val o = arr.getJSONObject(i)
                                val name = o.optString("name", "file_$i")
                                val size = o.optLong("sizeBytes", 0L).coerceAtLeast(0L)
                                val chunks = max(1, o.optInt("totalChunks", 1))
                                val sha256 = o.optString("sha256", "")
                                val splitWarn = o.optBoolean("hasSplitWarning", false)
                                val relPath = o.optString("relativePath", "")
                                val rootFolder = o.optString("rootFolderName", "")
                                val batchId = o.optString("folderBatchId", "")
                                val isDir = o.optBoolean("isDirectory", false)
                                list.add(
                                    TransferFileItem(
                                        id = o.optString("id", "rem_$i"),
                                        name = name,
                                        sizeBytes = size,
                                        category = FileCategory.fromFileName(name, isDirectory = isDir),
                                        relativePath = relPath,
                                        rootFolderName = rootFolder,
                                        folderBatchId = batchId,
                                        isDirectory = isDir,
                                        totalChunks = chunks,
                                        sha256Expected = sha256,
                                        hasSplitWarning = splitWarn
                                    )
                                )
                            }
                            if (list.isNotEmpty()) {
                                fetchedRemoteFiles = list
                                resolvedIp = targetIp
                                resolvedPort = targetPort
                                conn.disconnect()
                                break
                            }
                        }
                    }
                    conn.disconnect()
                } catch (_: Exception) {
                }
            }

            withContext(Dispatchers.Main) {
                val validFiles = fetchedRemoteFiles
                if (validFiles.isNullOrEmpty()) {
                    _uiState.update {
                        it.copy(
                            isConnectingToSender = false,
                            showReceiveConfirmationDialog = false,
                            pendingIncomingFiles = emptyList(),
                            statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                        )
                    }
                } else {
                    _uiState.update { state ->
                        state.copy(
                            isConnectingToSender = false,
                            enteredReceiveCode = sessionCode,
                            remoteHostIp = resolvedIp,
                            remoteHostPort = resolvedPort,
                            remoteSessionCode = sessionCode,
                            remoteChunkSizeBytes = remoteChunkSize,
                            pendingIncomingFiles = validFiles,
                            showReceiveConfirmationDialog = true,
                            currentScreen = AppScreen.RECEIVE,
                            statusBannerMessage = null
                        )
                    }
                }
            }
        }
    }

    private fun sendUdpFindQuery(code: String) {
        try {
            DatagramSocket().use { ds ->
                ds.broadcast = true
                val bytes = "BARQ_FIND|$code".toByteArray(Charsets.UTF_8)
                val pkt = DatagramPacket(
                    bytes,
                    bytes.size,
                    InetAddress.getByName("255.255.255.255"),
                    P2PChunkServer.UDP_DISCOVERY_PORT
                )
                ds.send(pkt)
            }
        } catch (_: Exception) {
        }
    }

    fun confirmAndStartReceiving() {
        val incoming = _uiState.value.pendingIncomingFiles
        if (incoming.isEmpty()) {
            _uiState.update { it.copy(showReceiveConfirmationDialog = false) }
            return
        }
        _uiState.update { state ->
            state.copy(
                files = incoming,
                pendingIncomingFiles = emptyList(),
                showReceiveConfirmationDialog = false
            )
        }
        startLiveChunkedTransfer(TransferDirection.RECEIVING)
    }

    fun cancelReceiveConfirmation() {
        _uiState.update { state ->
            state.copy(
                pendingIncomingFiles = emptyList(),
                showReceiveConfirmationDialog = false,
                statusBannerMessage = "تم إلغاء استلام الملفات"
            )
        }
    }

    fun togglePauseResume() {
        _uiState.update { state ->
            val newPaused = !state.isPaused
            val updatedFiles = state.files.map { f ->
                if (f.status == FileTransferStatus.TRANSFERRING || f.status == FileTransferStatus.PAUSED) {
                    f.copy(status = if (newPaused) FileTransferStatus.PAUSED else FileTransferStatus.TRANSFERRING)
                } else f
            }
            state.copy(
                isPaused = newPaused,
                files = updatedFiles,
                statusBannerMessage = if (newPaused) "تم إيقاف النقل مؤقتاً مع حفظ موضع الدفعة الحالية" else "تم استئناف النقل المباشر من آخر دفعة (Chunk)"
            )
        }
    }

    fun exportSelfApkToDownloads() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>()
            try {
                val sourceApk = File(appContext.applicationInfo.sourceDir)
                val outDir = resolveBarqSherDownloadsDir(appContext)
                val targetApk = File(outDir, "Barq-Sher.apk")
                sourceApk.inputStream().use { input ->
                    FileOutputStream(targetApk).use { output ->
                        input.copyTo(output, 64 * 1024)
                    }
                }
                val sizeMb = String.format(Locale.US, "%.1f MB", targetApk.length() / (1024.0 * 1024.0))
                withContext(Dispatchers.Main) {
                    _uiState.update { state ->
                        state.copy(
                            statusBannerMessage = "تم حفظ ملف التطبيق Barq-Sher.apk ($sizeMb) في التنزيلات، وعبر الرابط: http://${state.networkStatus.localIp}:${state.networkStatus.port}/barq-p2p.apk"
                        )
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "رابط تنزيل الـ APK جاهز: http://${it.networkStatus.localIp}:${it.networkStatus.port}/barq-p2p.apk")
                    }
                }
            }
        }
    }

    private fun recordHistoryItem(
        item: TransferFileItem,
        direction: TransferDirection,
        peerAddress: String,
        avgSpeedBytesPerSec: Double,
        errorMessage: String? = null
    ) {
        val record = TransferHistoryRecord(
            id = UUID.randomUUID().toString().take(10),
            fileName = item.displayPathOrName,
            sizeBytes = item.sizeBytes,
            category = item.category,
            direction = direction,
            status = item.status,
            timestampMillis = System.currentTimeMillis(),
            savedPath = item.savedPath,
            sha256Hash = item.sha256Actual.ifBlank { item.sha256Expected },
            sha256Verified = item.sha256Verified,
            averageSpeedBytesPerSec = avgSpeedBytesPerSec,
            peerAddress = peerAddress,
            errorMessage = errorMessage,
            relativePath = item.relativePath,
            rootFolderName = item.rootFolderName
        )
        _uiState.update { state ->
            val updated = (listOf(record) + state.transferHistory).take(100)
            savePersistedHistory(updated)
            state.copy(transferHistory = updated)
        }
    }

    fun clearTransferHistory() {
        _uiState.update { it.copy(transferHistory = emptyList()) }
        savePersistedHistory(emptyList())
    }

    private fun savePersistedHistory(records: List<TransferHistoryRecord>) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val arr = JSONArray()
                for (r in records) {
                    val o = JSONObject()
                    o.put("id", r.id)
                    o.put("fileName", r.fileName)
                    o.put("sizeBytes", r.sizeBytes)
                    o.put("category", r.category.name)
                    o.put("direction", r.direction.name)
                    o.put("status", r.status.name)
                    o.put("timestampMillis", r.timestampMillis)
                    o.put("savedPath", r.savedPath ?: "")
                    o.put("sha256Hash", r.sha256Hash)
                    o.put("sha256Verified", r.sha256Verified)
                    o.put("averageSpeedBytesPerSec", r.averageSpeedBytesPerSec)
                    o.put("peerAddress", r.peerAddress)
                    o.put("errorMessage", r.errorMessage ?: "")
                    o.put("relativePath", r.relativePath)
                    o.put("rootFolderName", r.rootFolderName)
                    arr.put(o)
                }
                val file = File(getApplication<Application>().filesDir, "barq_transfer_history.json")
                file.writeText(arr.toString())
            } catch (_: Exception) {
            }
        }
    }

    private fun loadPersistedHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = File(getApplication<Application>().filesDir, "barq_transfer_history.json")
                if (!file.exists()) return@launch
                val arr = JSONArray(file.readText())
                val list = mutableListOf<TransferHistoryRecord>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        TransferHistoryRecord(
                            id = o.optString("id"),
                            fileName = o.optString("fileName"),
                            sizeBytes = o.optLong("sizeBytes"),
                            category = runCatching { FileCategory.valueOf(o.optString("category")) }.getOrDefault(FileCategory.DOCUMENT),
                            direction = runCatching { TransferDirection.valueOf(o.optString("direction")) }.getOrDefault(TransferDirection.RECEIVING),
                            status = runCatching { FileTransferStatus.valueOf(o.optString("status")) }.getOrDefault(FileTransferStatus.COMPLETED),
                            timestampMillis = o.optLong("timestampMillis"),
                            savedPath = o.optString("savedPath").ifBlank { null },
                            sha256Hash = o.optString("sha256Hash"),
                            sha256Verified = o.optBoolean("sha256Verified"),
                            averageSpeedBytesPerSec = o.optDouble("averageSpeedBytesPerSec", 0.0),
                            peerAddress = o.optString("peerAddress"),
                            errorMessage = o.optString("errorMessage").ifBlank { null },
                            relativePath = o.optString("relativePath", ""),
                            rootFolderName = o.optString("rootFolderName", "")
                        )
                    )
                }
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(transferHistory = list) }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun updateFileState(fileId: String, transform: (TransferFileItem) -> TransferFileItem) {
        _uiState.update { state ->
            state.copy(files = state.files.map { if (it.id == fileId) transform(it) else it })
        }
    }

    override fun onCleared() {
        super.onCleared()
        chunkServer?.stopServer()
    }

    companion object {
        private const val WRITE_COALESCE_BYTES = 256 * 1024
        private const val STREAM_READ_BUFFER_BYTES = 64 * 1024
        private const val CONCURRENT_SMALL_FILES_LIMIT = 3

        /**
         * Sanitizes a relative path (e.g., "MyFolder/Sub1/file.txt") to prevent path traversal ("..")
         * while preserving nested directory structure and replacing the root folder segment if deduplicated.
         */
        fun resolveDestinationFileForTransferItem(
            downloadDir: File,
            item: TransferFileItem,
            rootFolderMap: Map<String, String>
        ): File {
            val rawRel = item.relativePath.trim().replace('\\', '/')
            if (rawRel.isBlank()) {
                val safeName = DeviceMediaRepository.sanitizePathSegment(item.name)
                return resolveUniqueStandaloneFile(downloadDir, safeName)
            }
            val segments = rawRel.split('/')
                .map { DeviceMediaRepository.sanitizePathSegment(it) }
                .filter { it.isNotBlank() && it != "." && it != ".." }
            if (segments.isEmpty()) {
                val safeName = DeviceMediaRepository.sanitizePathSegment(item.name)
                return resolveUniqueStandaloneFile(downloadDir, safeName)
            }
            val mappedSegments = segments.toMutableList()
            val originalRoot = mappedSegments[0]
            val mappedRoot = rootFolderMap[originalRoot] ?: originalRoot
            mappedSegments[0] = mappedRoot

            var current = downloadDir
            for (seg in mappedSegments) {
                current = File(current, seg)
            }
            return current
        }

        private fun resolveUniqueStandaloneFile(parentDir: File, fileName: String): File {
            val direct = File(parentDir, fileName)
            if (!direct.exists()) return direct
            val dotIdx = fileName.lastIndexOf('.')
            val stem = if (dotIdx > 0) fileName.substring(0, dotIdx) else fileName
            val ext = if (dotIdx > 0) fileName.substring(dotIdx) else ""
            var index = 1
            while (true) {
                val candidate = File(parentDir, "$stem ($index)$ext")
                if (!candidate.exists()) return candidate
                index++
            }
        }

        fun buildUniqueRootFolderMap(
            downloadDir: File,
            items: List<TransferFileItem>,
            isResumingSession: Boolean
        ): Map<String, String> {
            val map = LinkedHashMap<String, String>()
            val rootNames = items.mapNotNull {
                val r = it.rootFolderName.trim()
                if (r.isNotBlank()) DeviceMediaRepository.sanitizePathSegment(r)
                else it.relativePath.substringBefore('/', "").trim().takeIf { s -> s.isNotBlank() }?.let { s ->
                    DeviceMediaRepository.sanitizePathSegment(s)
                }
            }.distinct()

            for (root in rootNames) {
                val existing = File(downloadDir, root)
                if (!existing.exists() || isResumingSession) {
                    map[root] = root
                } else {
                    var counter = 1
                    while (true) {
                        val candidateName = "$root ($counter)"
                        if (!File(downloadDir, candidateName).exists()) {
                            map[root] = candidateName
                            break
                        }
                        counter++
                    }
                }
            }
            return map
        }

        /**
         * High-Speed Receiver Transfer Engine supporting:
         * 1. Exact folder hierarchy recreation (including empty directories and 0-byte files).
         * 2. Duplicate root folder & file name resolution.
         * 3. Persistent HTTP/1.1 Keep-Alive connection streaming (/api/stream with /api/chunk fallback).
         * 4. 256 KB coalesced disk writes and on-the-fly SHA-256 verification.
         * 5. Bounded 3-connection concurrency for multi-file folder transfers.
         */
        suspend fun executeHighSpeedReceiveSession(
            hostIp: String,
            hostPort: Int,
            sessionCode: String,
            chunkSizeBytes: Int,
            downloadDir: File,
            itemsProvider: () -> List<TransferFileItem>,
            isPausedProvider: () -> Boolean,
            onFileUpdated: (
                fileId: String,
                fileSpeedBytesPerSec: Double,
                sessionSpeedBytesPerSec: Double,
                transform: (TransferFileItem) -> TransferFileItem
            ) -> Unit,
            onFileCompleted: (TransferFileItem, Double) -> Unit,
            onFileFailed: (TransferFileItem, String) -> Unit
        ): Boolean = coroutineScope {
            if (!downloadDir.exists()) downloadDir.mkdirs()
            val allItems = itemsProvider()
            val isResuming = allItems.any { it.completedChunks > 0 || it.status == FileTransferStatus.COMPLETED }
            val rootFolderMap = buildUniqueRootFolderMap(downloadDir, allItems, isResuming)

            // Step 1: Explicitly create every selected root folder FIRST on the receiving phone before placing contents inside it
            for (mappedRootName in rootFolderMap.values) {
                File(downloadDir, mappedRootName).mkdirs()
            }

            val sessionStartNano = System.nanoTime()
            val sessionTotalBytes = AtomicLong(0L)
            var anyFailed = false

            // Step 2: Pre-create all nested subdirectories and immediately complete empty directory items
            val remainingFileItems = mutableListOf<TransferFileItem>()
            for (item in allItems) {
                if (item.status == FileTransferStatus.COMPLETED) continue
                val dest = resolveDestinationFileForTransferItem(downloadDir, item, rootFolderMap)
                if (item.isDirectory) {
                    dest.mkdirs()
                    sendAckToSender(hostIp, hostPort, sessionCode, item.id)
                    var doneSnap: TransferFileItem? = null
                    onFileUpdated(item.id, 0.0, 0.0) { f ->
                        val d = f.copy(
                            completedChunks = f.totalChunks,
                            transferredBytes = 0L,
                            status = FileTransferStatus.COMPLETED,
                            savedPath = dest.absolutePath,
                            sha256Actual = Sha256Util.EMPTY_DIR_SHA256,
                            sha256Verified = true,
                            errorMessage = null
                        )
                        doneSnap = d
                        d
                    }
                    doneSnap?.let { onFileCompleted(it, 0.0) }
                } else if (item.sizeBytes == 0L) {
                    dest.parentFile?.mkdirs()
                    if (!dest.exists()) dest.createNewFile()
                    sendAckToSender(hostIp, hostPort, sessionCode, item.id)
                    var doneSnap: TransferFileItem? = null
                    onFileUpdated(item.id, 0.0, 0.0) { f ->
                        val d = f.copy(
                            completedChunks = f.totalChunks,
                            transferredBytes = 0L,
                            status = FileTransferStatus.COMPLETED,
                            savedPath = dest.absolutePath,
                            sha256Actual = Sha256Util.EMPTY_BYTES_SHA256,
                            sha256Verified = true,
                            errorMessage = null
                        )
                        doneSnap = d
                        d
                    }
                    doneSnap?.let { onFileCompleted(it, 0.0) }
                } else {
                    dest.parentFile?.mkdirs()
                    remainingFileItems.add(item)
                }
            }

            // Partition into small/medium files (<= 4 MB) for bounded 3-worker concurrency, and large files (> 4 MB)
            val smallFiles = remainingFileItems.filter { it.sizeBytes <= 4L * 1024L * 1024L }
            val largeFiles = remainingFileItems.filter { it.sizeBytes > 4L * 1024L * 1024L }

            if (smallFiles.isNotEmpty()) {
                val semaphore = Semaphore(CONCURRENT_SMALL_FILES_LIMIT)
                val jobs = smallFiles.map { item ->
                    async(Dispatchers.IO) {
                        semaphore.withPermit {
                            val ok = downloadSingleFileOptimized(
                                item = item,
                                hostIp = hostIp,
                                hostPort = hostPort,
                                sessionCode = sessionCode,
                                chunkSizeBytes = chunkSizeBytes,
                                downloadDir = downloadDir,
                                rootFolderMap = rootFolderMap,
                                sessionStartNano = sessionStartNano,
                                sessionTotalBytes = sessionTotalBytes,
                                isPausedProvider = isPausedProvider,
                                onFileUpdated = onFileUpdated,
                                onFileCompleted = onFileCompleted,
                                onFileFailed = onFileFailed
                            )
                            if (!ok) anyFailed = true
                        }
                    }
                }
                jobs.awaitAll()
            }

            for (largeItem in largeFiles) {
                if (!isActive || anyFailed) break
                val ok = downloadSingleFileOptimized(
                    item = largeItem,
                    hostIp = hostIp,
                    hostPort = hostPort,
                    sessionCode = sessionCode,
                    chunkSizeBytes = chunkSizeBytes,
                    downloadDir = downloadDir,
                    rootFolderMap = rootFolderMap,
                    sessionStartNano = sessionStartNano,
                    sessionTotalBytes = sessionTotalBytes,
                    isPausedProvider = isPausedProvider,
                    onFileUpdated = onFileUpdated,
                    onFileCompleted = onFileCompleted,
                    onFileFailed = onFileFailed
                )
                if (!ok) {
                    anyFailed = true
                    break
                }
            }

            anyFailed
        }

        private suspend fun downloadSingleFileOptimized(
            item: TransferFileItem,
            hostIp: String,
            hostPort: Int,
            sessionCode: String,
            chunkSizeBytes: Int,
            downloadDir: File,
            rootFolderMap: Map<String, String>,
            sessionStartNano: Long,
            sessionTotalBytes: AtomicLong,
            isPausedProvider: () -> Boolean,
            onFileUpdated: (
                fileId: String,
                fileSpeedBytesPerSec: Double,
                sessionSpeedBytesPerSec: Double,
                transform: (TransferFileItem) -> TransferFileItem
            ) -> Unit,
            onFileCompleted: (TransferFileItem, Double) -> Unit,
            onFileFailed: (TransferFileItem, String) -> Unit
        ): Boolean = coroutineScope {
            val totalChunks = max(1, item.totalChunks)
            val finalOutFile = resolveDestinationFileForTransferItem(downloadDir, item, rootFolderMap)
            finalOutFile.parentFile?.mkdirs()
            val tempPartFile = File(finalOutFile.parentFile ?: downloadDir, "${finalOutFile.name}.part")

            onFileUpdated(item.id, 0.0, 0.0) {
                it.copy(status = FileTransferStatus.TRANSFERRING, errorMessage = null)
            }

            var currentChunkIdx = item.completedChunks.coerceIn(0, totalChunks - 1)
            if (currentChunkIdx > 0 && (!tempPartFile.exists() || tempPartFile.length() < currentChunkIdx.toLong() * chunkSizeBytes.toLong())) {
                currentChunkIdx = 0
            }

            val fileStartNano = System.nanoTime()
            var bytesDownloadedForThisFile = 0L
            var lastUiReportNano = 0L

            try {
                val digest = MessageDigest.getInstance("SHA-256")
                RandomAccessFile(tempPartFile, "rw").use { raf ->
                    val resumeOffset = currentChunkIdx.toLong() * chunkSizeBytes.toLong()
                    if (resumeOffset > 0L) {
                        // Hash already-downloaded prefix once so we can continue hashing on-the-fly
                        raf.seek(0L)
                        val hashScratch = ByteArray(STREAM_READ_BUFFER_BYTES)
                        var remPrefix = resumeOffset
                        while (remPrefix > 0L) {
                            val r = raf.read(hashScratch, 0, minOf(hashScratch.size.toLong(), remPrefix).toInt())
                            if (r <= 0) break
                            digest.update(hashScratch, 0, r)
                            remPrefix -= r
                        }
                    }

                    val encodedFileId = URLEncoder.encode(item.id, "UTF-8")
                    val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                    val readBuf = ByteArray(STREAM_READ_BUFFER_BYTES)
                    val writeCoalesceBuf = ByteArray(WRITE_COALESCE_BYTES)
                    var writeCoalescePos = 0

                    fun flushCoalescedWrites() {
                        if (writeCoalescePos > 0) {
                            raf.write(writeCoalesceBuf, 0, writeCoalescePos)
                            writeCoalescePos = 0
                        }
                    }

                    var currentByteOffset = resumeOffset
                    var streamAttempt = 0
                    while (currentByteOffset < item.sizeBytes && isActive) {
                        while (isPausedProvider() && isActive) {
                            delay(100)
                        }
                        if (!isActive) throw CancellationException("Transfer cancelled")

                        streamAttempt++
                        try {
                            raf.seek(currentByteOffset)
                            writeCoalescePos = 0
                            val streamUrl = URL(
                                "http://$hostIp:$hostPort/api/stream?fileId=$encodedFileId&offset=$currentByteOffset&chunkSize=$chunkSizeBytes&code=$encodedCode"
                            )
                            val conn = (streamUrl.openConnection() as HttpURLConnection).apply {
                                connectTimeout = 10_000
                                readTimeout = 25_000
                                requestMethod = "GET"
                                setRequestProperty("Connection", "keep-alive")
                            }

                            if (conn.responseCode == 200) {
                                BufferedInputStream(conn.inputStream, STREAM_READ_BUFFER_BYTES).use { input ->
                                    while (currentByteOffset < item.sizeBytes) {
                                        if (!isActive) {
                                            flushCoalescedWrites()
                                            conn.disconnect()
                                            throw CancellationException("Transfer cancelled")
                                        }
                                        if (isPausedProvider()) {
                                            flushCoalescedWrites()
                                            conn.disconnect()
                                            break
                                        }
                                        val readCount = input.read(readBuf)
                                        if (readCount == -1) break
                                        if (readCount > 0) {
                                            digest.update(readBuf, 0, readCount)
                                            if (writeCoalescePos + readCount > writeCoalesceBuf.size) {
                                                flushCoalescedWrites()
                                            }
                                            if (readCount >= writeCoalesceBuf.size) {
                                                raf.write(readBuf, 0, readCount)
                                            } else {
                                                System.arraycopy(readBuf, 0, writeCoalesceBuf, writeCoalescePos, readCount)
                                                writeCoalescePos += readCount
                                            }
                                            currentByteOffset += readCount
                                            bytesDownloadedForThisFile += readCount
                                            val totalSessionNow = sessionTotalBytes.addAndGet(readCount.toLong())

                                            val nowNano = System.nanoTime()
                                            if (currentByteOffset >= item.sizeBytes || (nowNano - lastUiReportNano) >= 45_000_000L) {
                                                lastUiReportNano = nowNano
                                                val fileElapsed = max(0.002, (nowNano - fileStartNano) / 1_000_000_000.0)
                                                val sessionElapsed = max(0.002, (nowNano - sessionStartNano) / 1_000_000_000.0)
                                                val fSpeed = bytesDownloadedForThisFile.toDouble() / fileElapsed
                                                val sSpeed = totalSessionNow.toDouble() / sessionElapsed
                                                val doneChunks = ((currentByteOffset + chunkSizeBytes - 1) / chunkSizeBytes).toInt()
                                                    .coerceIn(1, totalChunks)
                                                onFileUpdated(item.id, fSpeed, sSpeed) { f ->
                                                    f.copy(
                                                        completedChunks = doneChunks,
                                                        transferredBytes = minOf(f.sizeBytes, currentByteOffset),
                                                        currentSpeedBytesPerSec = fSpeed,
                                                        status = FileTransferStatus.TRANSFERRING
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    flushCoalescedWrites()
                                }
                                streamAttempt = 0
                            } else {
                                conn.disconnect()
                                throw IllegalStateException("HTTP ${conn.responseCode}")
                            }
                        } catch (ce: CancellationException) {
                            throw ce
                        } catch (e: Exception) {
                            flushCoalescedWrites()
                            if (streamAttempt >= 3) throw e
                            delay(250L * streamAttempt)
                        }
                    }
                }

                // Verify exact file size and on-the-fly SHA-256 digest
                onFileUpdated(item.id, 0.0, 0.0) {
                    it.copy(status = FileTransferStatus.VERIFYING, currentSpeedBytesPerSec = 0.0)
                }

                val actualLength = tempPartFile.length()
                if (actualLength != item.sizeBytes) {
                    throw IllegalStateException("حجم الملف المستلم ($actualLength بايت) لا يطابق الحجم الأصلي (${item.sizeBytes} بايت)")
                }

                val computedSha256 = Sha256Util.bytesToHex(digest.digest())
                val expectedSha256 = item.sha256Expected
                val shaMatches = expectedSha256.isBlank() || computedSha256.equals(expectedSha256, ignoreCase = true)
                if (!shaMatches) {
                    throw IllegalStateException("فشل التحقق من سلامة الملف (SHA-256 غير متطابق)")
                }

                if (finalOutFile.exists()) finalOutFile.delete()
                val renamed = tempPartFile.renameTo(finalOutFile)
                val savedFile = if (renamed) finalOutFile else tempPartFile

                sendAckToSender(hostIp, hostPort, sessionCode, item.id)

                val totalElapsedSec = max(0.002, (System.nanoTime() - fileStartNano) / 1_000_000_000.0)
                val avgSpeed = bytesDownloadedForThisFile.toDouble() / totalElapsedSec

                var completedSnapshot: TransferFileItem? = null
                onFileUpdated(item.id, avgSpeed, avgSpeed) { f ->
                    val done = f.copy(
                        completedChunks = totalChunks,
                        transferredBytes = f.sizeBytes,
                        currentSpeedBytesPerSec = 0.0,
                        status = FileTransferStatus.COMPLETED,
                        savedPath = savedFile.absolutePath,
                        sha256Actual = computedSha256,
                        sha256Verified = true,
                        errorMessage = null
                    )
                    completedSnapshot = done
                    done
                }

                completedSnapshot?.let { onFileCompleted(it, avgSpeed) }
                true
            } catch (ce: CancellationException) {
                if (tempPartFile.exists()) tempPartFile.delete()
                onFileUpdated(item.id, 0.0, 0.0) {
                    it.copy(status = FileTransferStatus.CANCELLED, currentSpeedBytesPerSec = 0.0)
                }
                throw ce
            } catch (e: Exception) {
                val errMsg = e.message ?: "انقطع الاتصال أثناء تحميل الدفعات"
                var failedSnap: TransferFileItem? = null
                onFileUpdated(item.id, 0.0, 0.0) { f ->
                    val failed = f.copy(
                        status = FileTransferStatus.FAILED,
                        currentSpeedBytesPerSec = 0.0,
                        errorMessage = errMsg
                    )
                    failedSnap = failed
                    failed
                }
                failedSnap?.let { onFileFailed(it, errMsg) }
                false
            }
        }

        private fun sendAckToSender(
            hostIp: String,
            hostPort: Int,
            sessionCode: String,
            fileId: String
        ) {
            try {
                val ackUrl = URL(
                    "http://$hostIp:$hostPort/api/ack?fileId=${URLEncoder.encode(fileId, "UTF-8")}&verified=true&code=${URLEncoder.encode(sessionCode, "UTF-8")}"
                )
                (ackUrl.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 2500
                    readTimeout = 2500
                    setRequestProperty("Connection", "keep-alive")
                    responseCode
                }
            } catch (_: Exception) {
            }
        }
    }
}

package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.model.AppScreen
import com.example.model.ChunkSizeOption
import com.example.model.DiscoveredPeerSession
import com.example.model.TransferFileItem
import com.example.ui.components.CopyrightFooter
import com.example.ui.components.QrCodeCanvas
import com.example.ui.components.categoryIcon
import com.example.ui.components.formatBytesArabic
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.HotspotAmber
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.MidnightCard
import com.example.ui.theme.MidnightCardElevated
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.P2PUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SendFilesScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onNavigateToCategory: (AppScreen) -> Unit,
    onPickFiles: (List<Uri>) -> Unit,
    onPickEntireFolder: (Uri) -> Unit = {},
    onRemoveFolderBatch: (String) -> Unit = {},
    onRemoveFile: (String) -> Unit,
    onRegenerateCode: () -> Unit,
    onSelectChunkSize: (ChunkSizeOption) -> Unit,
    onStartSending: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val multiFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            onPickFiles(uris)
        }
    }

    val folderTreePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) {
            onPickEntireFolder(treeUri)
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            ScreenTopBar(
                title = "إرسال ملفات ومجلدات وتطبيقات",
                subtitle = "اختر ملفات أو مجلدات كاملة ثم اضغط بدء الإرسال لتفعيل الجلسة",
                accentColor = ElectricCyan,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Short Connection Code + QR Code Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(MidnightSurface)
                    .border(1.2.dp, ElectricCyan.copy(alpha = 0.55f), RoundedCornerShape(22.dp))
                    .padding(18.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "كود الربط للجهاز المستلم",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextSecondary
                        )
                        Surface(
                            color = if (uiState.isSenderReady) NeonEmerald.copy(alpha = 0.2f) else HotspotAmber.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(999.dp)
                        ) {
                            Text(
                                text = if (uiState.isSenderReady) "مفعّل وجاهز للإرسال" else "بانتظار ضغط بدء الإرسال",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (uiState.isSenderReady) NeonEmerald else HotspotAmber,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF070E1B))
                            .border(1.dp, ElectricCyan.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = uiState.connectionCode,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 30.sp,
                            color = ElectricCyan,
                            modifier = Modifier.testTag("sender_short_code_text")
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        IconButton(
                            onClick = {
                                val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                cb?.setPrimaryClip(ClipData.newPlainText("BarqSher Code", uiState.connectionCode))
                            },
                            modifier = Modifier.testTag("copy_code_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = "نسخ كود الاتصال",
                                tint = ElectricCyan
                            )
                        }
                        IconButton(
                            onClick = onRegenerateCode,
                            modifier = Modifier.testTag("regenerate_code_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "تحديث الكود",
                                tint = HotspotAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    QrCodeCanvas(
                        content = uiState.qrPayload,
                        size = 186.dp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "العنوان المحلي: ${uiState.networkStatus.localIp}:${uiState.networkStatus.port} (${uiState.networkStatus.networkTypeLabel})",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 11.sp,
                        color = NeonEmerald,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Category Browsers to add Installed Apps, Photos, Videos, Audio, or Files
            Text(
                text = "إضافة من أقسام الهاتف:",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.APPS) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("send_pick_from_apps_button")
                ) {
                    Icon(Icons.Filled.Android, contentDescription = null, tint = NeonEmerald, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("التطبيقات (${uiState.installedApps.size})", fontSize = 12.sp, color = Color.White)
                }
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.IMAGES) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.Image, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("الصور", fontSize = 12.sp, color = Color.White)
                }
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.VIDEOS) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.Movie, contentDescription = null, tint = CoralRose, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("الفيديوهات", fontSize = 12.sp, color = Color.White)
                }
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.AUDIO) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.MusicNote, contentDescription = null, tint = Color(0xFFEC4899), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("الصوتيات", fontSize = 12.sp, color = Color.White)
                }
                OutlinedButton(
                    onClick = { onNavigateToCategory(AppScreen.FILES) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.Folder, contentDescription = null, tint = HotspotAmber, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("الملفات والمجلدات", fontSize = 12.sp, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Open In-App Folders & Files Selection Screen (with selection circles next to folders & files)
            Button(
                onClick = {
                    onNavigateToCategory(AppScreen.FILES)
                },
                enabled = !uiState.isScanningFolder,
                colors = ButtonDefaults.buttonColors(containerColor = HotspotAmber),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("send_pick_entire_folder_button")
            ) {
                if (uiState.isScanningFolder) {
                    CircularProgressIndicator(
                        color = Color(0xFF1F1200),
                        strokeWidth = 2.5.dp,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "جاري تجهيز المجلدات والملفات المحددة...",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF1F1200),
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.Folder,
                        contentDescription = null,
                        tint = Color(0xFF1F1200)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "اختيار مجلدات وملفات من القائمة (مع دائرة تحديد لكل مجلد)",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color(0xFF1F1200),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Chunk Size Selector
            Text(
                text = "حجم الدفعة (Chunking) المتكيف مع الشبكة:",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                ChunkSizeOption.entries.forEach { option ->
                    val selected = option == uiState.selectedChunkSize
                    Surface(
                        color = if (selected) ElectricCyan.copy(alpha = 0.22f) else MidnightCard,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) ElectricCyan else GlassBorder
                        ),
                        modifier = Modifier
                            .clickable { onSelectChunkSize(option) }
                            .testTag("chunk_option_${option.name}")
                    ) {
                        Text(
                            text = option.label,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp,
                            color = if (selected) ElectricCyan else Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Unified Send Queue Header (Each selected folder counts as 1 transfer unit alongside standalone files)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "قائمة الإرسال المحددة (${uiState.totalSelectedUnitsInSendQueue} عنصر)",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    modifier = Modifier.testTag("send_queue_units_count_label")
                )
                Text(
                    text = "الإجمالي: ${formatBytesArabic(uiState.totalBytes)} • ${uiState.totalChunksCount} دفعة",
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 12.sp,
                    color = ElectricCyan,
                    modifier = Modifier.testTag("send_queue_total_bytes_label")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (uiState.files.isEmpty() && uiState.folderBatches.isEmpty()) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MidnightCard)
                        .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                        .padding(24.dp)
                ) {
                    Text(
                        text = "قائمة الإرسال فارغة. اضغط «اختيار مجلدات وملفات من القائمة» أعلاه لتحديد أي مجلد مثل (Download/ropon) أو عدة مجلدات وملفات معاً عبر دائرة الاختيار ثم إرسالها.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                // 1. Render each selected Folder as a single unified transfer item in the queue
                uiState.folderBatches.forEach { batch ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF211709))
                            .border(1.2.dp, HotspotAmber.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                            .testTag("folder_batch_card_${batch.batchId}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(HotspotAmber.copy(alpha = 0.2f))
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Folder,
                                    contentDescription = null,
                                    tint = HotspotAmber,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "مجلد كامل: ${batch.rootFolderName} (${batch.sourceUriOrPath})",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "عنصر نقل واحد يشمل: ${batch.totalFilesCount} ملف • ${batch.totalSubfoldersCount} مجلد فرعي (${batch.emptyFoldersCount} فارغ) • ${formatBytesArabic(batch.totalBytes)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFFFDE68A)
                                )
                            }
                        }
                        IconButton(onClick = { onRemoveFolderBatch(batch.batchId) }) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = "إزالة المجلد بالكامل",
                                tint = CoralRose
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // 2. Render standalone selected files alongside the unified folder items
                uiState.standaloneFilesInQueue.forEach { item ->
                    SelectedFileQueueRow(
                        item = item,
                        onRemove = { onRemoveFile(item.id) }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Start Live Chunked Transfer CTA
            Button(
                onClick = onStartSending,
                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .testTag("start_live_sending_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Send,
                    contentDescription = null,
                    tint = Color(0xFF002418)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "بدء الإرسال وتفعيل جلسة النقل للمستلم",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color(0xFF002418),
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        CopyrightFooter()
    }
}

@Composable
private fun SelectedFileQueueRow(
    item: TransferFileItem,
    onRemove: () -> Unit
) {
    val badgeColor = Color(item.category.badgeColorHex)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MidnightCard)
            .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(badgeColor.copy(alpha = 0.18f))
            ) {
                Icon(
                    imageVector = categoryIcon(item.category),
                    contentDescription = item.category.arabicLabel,
                    tint = badgeColor,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = item.displayPathOrName,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (item.isDirectory) {
                        "مجلد فرعي فارغ داخل (${item.rootFolderName}) • يُعاد إنشاؤه تلقائياً"
                    } else if (item.rootFolderName.isNotBlank()) {
                        "ضمن مجلد (${item.rootFolderName}) • ${item.category.arabicLabel} • ${formatBytesArabic(item.sizeBytes)}"
                    } else {
                        "${item.category.arabicLabel} • ${formatBytesArabic(item.sizeBytes)} • ${item.totalChunks} دفعة"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                if (item.hasSplitWarning) {
                    Text(
                        text = "تنبيه: هذا التطبيق متعدد الحزم (Split APK)؛ سيتم إرسال ملف APK الأساسي.",
                        style = MaterialTheme.typography.labelMedium,
                        color = HotspotAmber,
                        fontSize = 11.sp
                    )
                }
            }
        }
        IconButton(onClick = onRemove) {
            Icon(
                imageVector = Icons.Filled.DeleteOutline,
                contentDescription = "حذف الملف",
                tint = CoralRose
            )
        }
    }
}

@Composable
fun ReceiveFilesScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onCodeChanged: (String) -> Unit,
    onConnectWithCode: (String) -> Unit,
    onConnectDiscoveredPeer: (DiscoveredPeerSession) -> Unit,
    onConfirmReceive: () -> Unit,
    onCancelReceive: () -> Unit,
    onOpenQrScanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val scrollState = rememberScrollState()

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            ScreenTopBar(
                title = "استلام ملفات • برق sher",
                subtitle = "اكتشاف تلقائي أو ربط بالكود / QR مع تأكيد قبل التحميل",
                accentColor = NeonEmerald,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Auto-Discovered Active Senders on the local network (UDP Discovery)
            if (uiState.discoveredPeers.isNotEmpty()) {
                Text(
                    text = "أجهزة مرسلة نشطة تم اكتشافها على الشبكة:",
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonEmerald
                )
                Spacer(modifier = Modifier.height(8.dp))
                uiState.discoveredPeers.forEach { peer ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF0B2520))
                            .border(1.2.dp, NeonEmerald, RoundedCornerShape(16.dp))
                            .clickable { onConnectDiscoveredPeer(peer) }
                            .padding(14.dp)
                            .testTag("discovered_peer_${peer.sessionCode}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Radar, contentDescription = null, tint = NeonEmerald, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "${peer.deviceName} (${peer.sessionCode})",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${peer.fileCount} ملفات • ${formatBytesArabic(peer.totalBytes)} • ${peer.hostIp}:${peer.port}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ElectricCyan
                                )
                            }
                        }
                        Button(
                            onClick = { onConnectDiscoveredPeer(peer) },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("اتصال", color = Color(0xFF002418), fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Code Input Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(MidnightSurface)
                    .border(1.2.dp, NeonEmerald.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "أدخل كود الاتصال الظاهر في الهاتف المرسل",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Text(
                        text = "يدعم الكود القصير (مثل BRQ-4301) أو العنوان المباشر (IP:Port#Code)",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = uiState.enteredReceiveCode,
                        onValueChange = onCodeChanged,
                        placeholder = {
                            Text(
                                text = "أدخل الكود هنا (مثال: BRQ-4301)",
                                fontFamily = JetBrainsMonoFontFamily,
                                color = TextSecondary,
                                fontSize = 14.sp
                            )
                        },
                        textStyle = TextStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                            color = NeonEmerald,
                            textAlign = TextAlign.Center
                        ),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonEmerald,
                            unfocusedBorderColor = GlassBorder,
                            focusedContainerColor = Color(0xFF070E1B),
                            unfocusedContainerColor = Color(0xFF070E1B)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("receive_code_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { onConnectWithCode(uiState.enteredReceiveCode) },
                        enabled = !uiState.isConnectingToSender,
                        colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("connect_by_code_button")
                    ) {
                        if (uiState.isConnectingToSender) {
                            CircularProgressIndicator(
                                color = Color(0xFF002418),
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "جاري البحث والتحقق من المرسل...",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF002418),
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Link,
                                contentDescription = null,
                                tint = Color(0xFF002418)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ربط والتحقق من الملفات المرسلة",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF002418),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // QR Code Scanner Option Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(MidnightCard)
                    .border(1.dp, ElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(ElectricCyan.copy(alpha = 0.16f))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.QrCodeScanner,
                            contentDescription = "ماسح رمز QR",
                            tint = ElectricCyan,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "مسح رمز QR Code من الهاتف المرسل",
                        style = MaterialTheme.typography.titleLarge,
                        color = Color.White
                    )
                    Text(
                        text = "يتضمن رمز الـ QR عنوان الـ IP الدقيق والمنفذ وكود الجلسة للاتصال الفوري على أي شبكة",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onOpenQrScanner,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("open_qr_scanner_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CameraAlt,
                            contentDescription = null,
                            tint = Color(0xFF002229)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "فتح الكاميرا لمسح رمز QR",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFF002229),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Direct Storage & SHA-256 Info Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF0B1526))
                    .border(1.dp, GlassBorder, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "📁 الحفظ والتحقق الآمن: بعد موافقتك على قائمة الملفات، يتم تحميل القطع وحفظها في (Downloads/BarqSher) مع فحص البصمة الرقمية (SHA-256) لكل ملف للتأكد من اكتماله دون تلف.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        CopyrightFooter()
    }

    // Confirmation Dialog displaying incoming files before starting chunk download
    if (uiState.showReceiveConfirmationDialog && uiState.pendingIncomingFiles.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = onCancelReceive,
            containerColor = MidnightCardElevated,
            title = {
                Column {
                    Text(
                        text = "تأكيد استلام الملفات والمجلدات من المرسل",
                        style = MaterialTheme.typography.titleLarge,
                        color = NeonEmerald,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "عدد العناصر: ${uiState.pendingIncomingFiles.size} • الإجمالي: ${formatBytesArabic(uiState.pendingTotalBytes)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ElectricCyan
                    )
                    if (uiState.pendingFolderNames.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "📁 مجلدات كاملة سيتم إعادة إنشائها ببنيتها الأصلية: ${uiState.pendingFolderNames.joinToString(" ، ")}",
                            style = MaterialTheme.typography.labelMedium,
                            color = HotspotAmber
                        )
                    }
                }
            },
            text = {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 280.dp)
                        .testTag("receive_confirmation_files_list")
                ) {
                    items(uiState.pendingIncomingFiles, key = { it.id }) { file ->
                        val badgeColor = Color(file.category.badgeColorHex)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MidnightCard)
                                .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
                                .padding(10.dp)
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(badgeColor.copy(alpha = 0.2f))
                            ) {
                                Icon(
                                    imageVector = categoryIcon(file.category),
                                    contentDescription = file.category.arabicLabel,
                                    tint = badgeColor,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = file.displayPathOrName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (file.isDirectory) {
                                        "مجلد فرعي فارغ داخل (${file.rootFolderName})"
                                    } else {
                                        "${file.category.arabicLabel} • ${formatBytesArabic(file.sizeBytes)}"
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onConfirmReceive,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("confirm_receive_files_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF002418),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تأكيد وبدء استلام الملفات",
                        color = Color(0xFF002418),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = onCancelReceive,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("cancel_receive_files_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = null,
                        tint = CoralRose,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "إلغاء",
                        color = CoralRose,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )
    }
}

@Composable
fun QrScannerScreen(
    uiState: P2PUiState,
    onBack: () -> Unit,
    onQrDetected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var manualScannedCode by remember { mutableStateOf("") }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    val laserTransition = rememberInfiniteTransition(label = "laser_scan")
    val laserOffsetFraction by laserTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            ScreenTopBar(
                title = "مسح رمز QR • برق sher",
                subtitle = "وجّه الكاميرا نحو رمز QR في الهاتف المرسل",
                accentColor = ElectricCyan,
                onBack = onBack
            )

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF050A14))
                    .border(2.dp, ElectricCyan.copy(alpha = 0.7f), RoundedCornerShape(24.dp))
            ) {
                if (hasCameraPermission) {
                    AndroidView(
                        factory = { ctx ->
                            PreviewView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                cameraProviderFuture.addListener({
                                    try {
                                        val provider = cameraProviderFuture.get()
                                        val preview = Preview.Builder().build().also {
                                            it.setSurfaceProvider(surfaceProvider)
                                        }
                                        provider.unbindAll()
                                        provider.bindToLifecycle(
                                            lifecycleOwner,
                                            CameraSelector.DEFAULT_BACK_CAMERA,
                                            preview
                                        )
                                    } catch (_: Exception) {
                                    }
                                }, ContextCompat.getMainExecutor(ctx))
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CameraAlt,
                            contentDescription = null,
                            tint = ElectricCyan,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "يلزم إذن الكاميرا لمسح رمز QR من الجوال المرسل",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                            modifier = Modifier.testTag("grant_camera_permission_button")
                        ) {
                            Text("السماح باستخدام الكاميرا", color = Color(0xFF002229), fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val frameSize = size.minDimension * 0.68f
                    val left = (size.width - frameSize) / 2f
                    val top = (size.height - frameSize) / 2f
                    val laserY = top + frameSize * laserOffsetFraction

                    drawLine(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, ElectricCyan, NeonEmerald, Color.Transparent)
                        ),
                        start = Offset(left, laserY),
                        end = Offset(left + frameSize, laserY),
                        strokeWidth = 4.dp.toPx()
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = manualScannedCode,
                    onValueChange = { manualScannedCode = it },
                    placeholder = { Text("أو الصق بيانات QR / الكود (BRQ-XXXX)", fontSize = 13.sp) },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = { onQrDetected(manualScannedCode) },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.height(52.dp)
                ) {
                    Text("ربط", color = Color(0xFF002418), fontWeight = FontWeight.Bold)
                }
            }
        }

        CopyrightFooter()
    }
}

@Composable
fun ScreenTopBar(
    title: String,
    subtitle: String,
    accentColor: Color,
    onBack: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MidnightCard)
                .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
                .testTag("navigate_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "رجوع",
                tint = accentColor
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
    }
}

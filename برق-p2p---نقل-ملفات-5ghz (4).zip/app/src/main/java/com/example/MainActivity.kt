package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppScreen
import com.example.model.FileCategory
import com.example.model.TransferDirection
import com.example.ui.screens.FilesAndFoldersScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InstalledAppsScreen
import com.example.ui.screens.LiveTransferScreen
import com.example.ui.screens.MediaCategoryScreen
import com.example.ui.screens.QrScannerScreen
import com.example.ui.screens.ReceiveFilesScreen
import com.example.ui.screens.SendFilesScreen
import com.example.ui.screens.TransferHistoryScreen
import com.example.ui.screens.WebRtcPeerJsPortalScreen
import com.example.ui.theme.CoralRose
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.MidnightBg
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.P2PTransferViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                BarqP2PApp()
            }
        }
    }
}

private data class NavTabSpec(
    val screen: AppScreen,
    val label: String,
    val icon: ImageVector
)

@Composable
fun BarqP2PApp(
    viewModel: P2PTransferViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    val mainTabs = listOf(
        NavTabSpec(AppScreen.HOME, "الرئيسية", Icons.Filled.Home),
        NavTabSpec(AppScreen.APPS, "التطبيقات", Icons.Filled.Android),
        NavTabSpec(AppScreen.IMAGES, "الصور", Icons.Filled.Image),
        NavTabSpec(AppScreen.VIDEOS, "الفيديوهات", Icons.Filled.Movie),
        NavTabSpec(AppScreen.AUDIO, "الصوتيات", Icons.Filled.MusicNote),
        NavTabSpec(AppScreen.FILES, "الملفات", Icons.Filled.Folder),
        NavTabSpec(AppScreen.SEND, "إرسال", Icons.Filled.CloudUpload),
        NavTabSpec(AppScreen.RECEIVE, "استلام", Icons.Filled.CloudDownload),
        NavTabSpec(AppScreen.HISTORY, "سجل النقل", Icons.Filled.History)
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBg),
        containerColor = MidnightBg,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            Surface(
                color = MidnightSurface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("main_bottom_tabs_row")
                ) {
                    items(mainTabs, key = { it.screen.name }) { tab ->
                        val selected = uiState.currentScreen == tab.screen ||
                            (tab.screen == AppScreen.RECEIVE && uiState.currentScreen == AppScreen.QR_SCANNER) ||
                            (tab.screen == AppScreen.SEND && uiState.currentScreen == AppScreen.LIVE_TRANSFER)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (selected) ElectricCyan.copy(alpha = 0.18f) else Color.Transparent
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (selected) ElectricCyan else GlassBorder.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { viewModel.navigateTo(tab.screen) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .testTag("bottom_nav_${tab.screen.name}")
                        ) {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label,
                                tint = if (selected) ElectricCyan else TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = tab.label,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                color = if (selected) ElectricCyan else TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedVisibility(
                visible = uiState.statusBannerMessage != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                uiState.statusBannerMessage?.let { msg ->
                    val isError = msg.startsWith("فشل") || msg.startsWith("الرجاء") ||
                        msg.startsWith("انقطع") || msg.startsWith("تعذر")
                    val borderColor = if (isError) CoralRose else NeonEmerald
                    val bgColor = if (isError) Color(0xFF2D0C16) else Color(0xFF0A2924)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(bgColor)
                            .border(1.dp, borderColor.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                            .clickable { viewModel.clearBannerMessage() }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("status_banner_box")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = msg,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "إغلاق",
                                style = MaterialTheme.typography.labelMedium,
                                color = borderColor
                            )
                        }
                    }
                }
            }

            Box(modifier = Modifier.weight(1f)) {
                when (uiState.currentScreen) {
                    AppScreen.HOME -> HomeScreen(
                        uiState = uiState,
                        onNavigate = { viewModel.navigateTo(it) },
                        onRefreshNetwork = { viewModel.refreshNetworkStatus() },
                        onShowHotspotGuide = { viewModel.toggleHotspotGuideSheet(it) },
                        onExportApk = { viewModel.exportSelfApkToDownloads() },
                        onPickEntireFolderToSend = { viewModel.onSendEntireFolderTreePicked(it) },
                        onClearSelection = { viewModel.clearAllManagerSelections() },
                        onAddSelectedToSend = { viewModel.addManagerSelectionsToSendQueueAndGoToSend() }
                    )

                    AppScreen.APPS -> InstalledAppsScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onSearchQueryChange = { viewModel.updateAppsSearchQuery(it) },
                        onToggleSystemApps = { viewModel.loadInstalledApps(it) },
                        onRefreshApps = { viewModel.loadInstalledApps() },
                        onToggleSelectApp = { viewModel.toggleAppSelection(it) },
                        onSelectAllVisible = { viewModel.selectAllVisibleApps(it) },
                        onClearSelection = { viewModel.clearAllManagerSelections() },
                        onAddSelectedToSend = { viewModel.addManagerSelectionsToSendQueueAndGoToSend() }
                    )

                    AppScreen.IMAGES -> MediaCategoryScreen(
                        title = "الصور",
                        subtitle = "صور المعرض والكاميرا مع معاينة مصغرة حقيقية",
                        category = FileCategory.IMAGE,
                        items = uiState.deviceImages,
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onSearchQueryChange = { viewModel.updateMediaSearchQuery(it) },
                        onSortOptionChange = { viewModel.setSortOption(it) },
                        onPermissionsResult = { viewModel.onMediaPermissionsResult(it) },
                        onRefreshMedia = { viewModel.loadAllDeviceMediaAndFiles() },
                        onPickSafFiles = { viewModel.addPickedUris(it) },
                        onToggleSelectMedia = { viewModel.toggleMediaSelection(it) },
                        onSelectAllVisible = { viewModel.selectAllVisibleMedia(it) },
                        onClearSelection = { viewModel.clearAllManagerSelections() },
                        onAddSelectedToSend = { viewModel.addManagerSelectionsToSendQueueAndGoToSend() }
                    )

                    AppScreen.VIDEOS -> MediaCategoryScreen(
                        title = "الفيديوهات",
                        subtitle = "مقاطع الفيديو مع المدة والحجم الفعلي",
                        category = FileCategory.VIDEO,
                        items = uiState.deviceVideos,
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onSearchQueryChange = { viewModel.updateMediaSearchQuery(it) },
                        onSortOptionChange = { viewModel.setSortOption(it) },
                        onPermissionsResult = { viewModel.onMediaPermissionsResult(it) },
                        onRefreshMedia = { viewModel.loadAllDeviceMediaAndFiles() },
                        onPickSafFiles = { viewModel.addPickedUris(it) },
                        onToggleSelectMedia = { viewModel.toggleMediaSelection(it) },
                        onSelectAllVisible = { viewModel.selectAllVisibleMedia(it) },
                        onClearSelection = { viewModel.clearAllManagerSelections() },
                        onAddSelectedToSend = { viewModel.addManagerSelectionsToSendQueueAndGoToSend() }
                    )

                    AppScreen.AUDIO -> MediaCategoryScreen(
                        title = "الموسيقى والصوتيات",
                        subtitle = "الملفات الصوتية والأغاني مع المدة والحجم",
                        category = FileCategory.AUDIO,
                        items = uiState.deviceAudio,
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onSearchQueryChange = { viewModel.updateMediaSearchQuery(it) },
                        onSortOptionChange = { viewModel.setSortOption(it) },
                        onPermissionsResult = { viewModel.onMediaPermissionsResult(it) },
                        onRefreshMedia = { viewModel.loadAllDeviceMediaAndFiles() },
                        onPickSafFiles = { viewModel.addPickedUris(it) },
                        onToggleSelectMedia = { viewModel.toggleMediaSelection(it) },
                        onSelectAllVisible = { viewModel.selectAllVisibleMedia(it) },
                        onClearSelection = { viewModel.clearAllManagerSelections() },
                        onAddSelectedToSend = { viewModel.addManagerSelectionsToSendQueueAndGoToSend() }
                    )

                    AppScreen.FILES -> FilesAndFoldersScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onSubTabChange = { viewModel.setActiveFilesSubTab(it) },
                        onSearchQueryChange = { viewModel.updateMediaSearchQuery(it) },
                        onSortOptionChange = { viewModel.setSortOption(it) },
                        onPickSafFiles = { viewModel.addPickedUris(it) },
                        onPickSafFolder = { viewModel.onSafFolderPicked(it) },
                        onSendLocalFolderDirectly = { viewModel.sendLocalFolderDirectly(it) },
                        onRefreshFiles = { viewModel.loadAllDeviceMediaAndFiles() },
                        onToggleSelectMedia = { viewModel.toggleMediaSelection(it) },
                        onSelectAllVisible = { viewModel.selectAllVisibleMedia(it) },
                        onClearSelection = { viewModel.clearAllManagerSelections() },
                        onAddSelectedToSend = { viewModel.addManagerSelectionsToSendQueueAndGoToSend() },
                        onToggleSelectFolder = { viewModel.toggleFolderSelection(it) },
                        onSelectAllVisibleFoldersAndFiles = { folders, files ->
                            viewModel.selectAllVisibleFoldersAndMedia(folders, files)
                        },
                        onAddOrSelectFolderByPath = { viewModel.addOrSelectFolderByPath(it) },
                        onSetBrowsingFolderFilter = { viewModel.setBrowsingFolderFilter(it) },
                        onPermissionsResult = { viewModel.onMediaPermissionsResult(it) }
                    )

                    AppScreen.SEND -> SendFilesScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onNavigateToCategory = { viewModel.navigateTo(it) },
                        onPickFiles = { viewModel.addPickedUris(it) },
                        onPickEntireFolder = { viewModel.onSendEntireFolderTreePicked(it) },
                        onRemoveFolderBatch = { viewModel.removeFolderBatch(it) },
                        onRemoveFile = { viewModel.removeFileItem(it) },
                        onRegenerateCode = { viewModel.regenerateConnectionCode() },
                        onSelectChunkSize = { viewModel.setChunkSize(it) },
                        onStartSending = {
                            viewModel.startLiveChunkedTransfer(TransferDirection.SENDING)
                        }
                    )

                    AppScreen.RECEIVE -> ReceiveFilesScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onCodeChanged = { viewModel.updateEnteredReceiveCode(it) },
                        onConnectWithCode = { code ->
                            viewModel.connectAndReceiveFromInput(code)
                        },
                        onConnectDiscoveredPeer = { peer ->
                            viewModel.connectToDiscoveredPeer(peer)
                        },
                        onConfirmReceive = { viewModel.confirmAndStartReceiving() },
                        onCancelReceive = { viewModel.cancelReceiveConfirmation() },
                        onOpenQrScanner = { viewModel.navigateTo(AppScreen.QR_SCANNER) }
                    )

                    AppScreen.HISTORY -> TransferHistoryScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onClearHistory = { viewModel.clearTransferHistory() }
                    )

                    AppScreen.QR_SCANNER -> QrScannerScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.RECEIVE) },
                        onQrDetected = { qrPayload ->
                            viewModel.connectAndReceiveFromInput(qrPayload)
                        }
                    )

                    AppScreen.LIVE_TRANSFER -> LiveTransferScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) },
                        onTogglePauseResume = { viewModel.togglePauseResume() },
                        onCancelTransfer = { viewModel.cancelActiveTransfer() },
                        onRestartTransfer = {
                            viewModel.startLiveChunkedTransfer(uiState.transferDirection)
                        }
                    )

                    AppScreen.WEBRTC_PORTAL -> WebRtcPeerJsPortalScreen(
                        uiState = uiState,
                        onBack = { viewModel.navigateTo(AppScreen.HOME) }
                    )
                }
            }
        }
    }
}
